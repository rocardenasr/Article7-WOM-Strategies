import unittest,json
from pathlib import Path
from dataclasses import asdict,replace
from hashlib import sha256
from article7.model import Config,Model
from article7.sensitivity import scenario_definitions,design_document


class SensitivityVerification(unittest.TestCase):
    def test_design_count_and_domains(self):
        d=design_document(asdict(Config()))
        self.assertEqual(len(d['scenarios']),24)
        self.assertEqual(len({s['scenario'] for s in d['scenarios']}),24)
        self.assertEqual(len(d['seeds'])*len(d['policies'])*len(d['scenarios']),16800)
        for s in d['scenarios']:Config(**s['config']).validate()

    def test_network_expected_degree_constant(self):
        for sid,family,changes in scenario_definitions():
            if family=='network':self.assertAlmostEqual(99*changes['p_in']+500*changes['p_out'],9.92)

    def test_time_value_changes_only_accounting(self):
        # Nonzero campaigns and times; includes committed events and adaptive action.
        for policy in 'ABCDEFG':
            base=Model(Config(),2001,policy).run()
            for value in [0.,4.]:
                other=Model(replace(Config(),time_cost=value),2001,policy).run()
                for key in ['new_customers','profit','hours','marketing_cost','events','event_links','unserved']:
                    self.assertEqual(base['summary'][key],other['summary'][key])
                self.assertAlmostEqual(other['summary']['adjusted_profit'],base['summary']['profit']-value*base['summary']['hours'])
                self.assertEqual(base['tables']['decisions'],other['tables']['decisions'])

    def test_adaptive_parameters_do_not_change_fixed_policies(self):
        c=replace(Config(),months=12)
        modified=replace(c,threshold_customers=24,threshold_promoters=8,threshold_activity=.24,min_exposures=16)
        for policy in 'ABCDEF':
            a=Model(c,2001,policy).run();b=Model(modified,2001,policy).run()
            # Feasibility is not adaptive for A--F; complete records must match.
            self.assertEqual(a,b)

    def test_reference_engine_unmodified(self):
        path=Path(__file__).resolve().parents[1]
        # Reference hash frozen by the completed baseline experiment.
        self.assertEqual(sha256((path/'article7/model.py').read_bytes()).hexdigest(),
                         'e12ba5f7aee01d63f23cce62751b383d77f2651eeb99aa5608955bf9cb3a4441')


if __name__=='__main__':unittest.main(verbosity=2)
