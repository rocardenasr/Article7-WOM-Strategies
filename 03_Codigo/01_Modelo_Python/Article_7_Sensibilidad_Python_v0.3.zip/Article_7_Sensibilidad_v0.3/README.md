# Article 7 — Sensibilidad en Python v0.3

Esta entrega extiende los experimentos del motor **0.2.0**, cuyo código y reglas se conservan. El diseño experimental y el paquete de análisis se identifican como **v0.3**. Los parámetros son ilustrativos y no están calibrados empíricamente.

## Contenido y alcance

El diseño contiene 24 escenarios nuevos, siete políticas y 100 semillas emparejadas por escenario/política: **16.800 simulaciones nuevas**. La referencia incluye las 700 ejecuciones basales ya realizadas. Los datos originales del piloto no entran en esta comparación.

Los escenarios estudian conversión, necesidad, costos de referidos/eventos, recompensa, presupuesto, capacidad, segregación de la red y tres bloques de umbrales adaptativos. Dos escenarios combinan necesidad/conversión altas, con y sin capacidad escasa. Se evalúan tres costos por hora contablemente sobre las mismas trayectorias; no son simulaciones adicionales.

## Ejecutar

Requiere Python 3.10 o superior. Desde la carpeta del paquete:

```bash
python -m pip install -r requirements-tested.txt
python -m unittest discover -s tests -v
python -m article7.sensitivity --design configs/sensitivity_design_v0.3.json --out outputs/sensitivity_v0.3 --baseline reference_baseline --workers 4
python -m article7.analyze_sensitivity --source outputs/sensitivity_v0.3 --baseline reference_baseline --out outputs/sensitivity_analysis_v0.3
```

`reference_baseline/` contiene los resúmenes, series, decisiones, auditoría y manifiesto del experimento basal necesarios para la comparación. Sus trazas completas permanecen en el paquete original `Article_7_Principal_700_v0.2.zip`. El ejecutor verifica que el hash del motor coincida con el de ese experimento antes de empezar.

Los directorios nuevos de experimentos deben estar vacíos. Se puede reducir `--workers` para ejecutar en equipos con menos memoria o procesadores; esto no altera los sorteos indexados. Una interrupción conserva las salidas parciales y los errores; el ejecutor no sobrescribe ni reanuda automáticamente un directorio no vacío.

## Reproducir solo el análisis

Extraiga **todas** las partes `Article_7_Sensibilidad_datos_v0.3_parte*.zip` en un mismo directorio vacío. Las partes tienen rutas disjuntas bajo `sensitivity_v0.3/` y contienen, en conjunto, todos los escenarios y registros. El índice de entregables enumera qué contiene cada parte. Pase esa carpeta al argumento `--source`; pase `reference_baseline` al argumento `--baseline`.

```bash
python -m article7.analyze_sensitivity --source datos/sensitivity_v0.3 --baseline reference_baseline --out analysis_reproduced
```

La clave global es `(scenario, run_id)`. Un run_id como `s2001_A` se repite legítimamente en diferentes escenarios. Las trazas heredan el escenario de la carpeta y su manifiesto; las tablas agregadas lo incluyen como columna.

## Evidencia y límites

- `docs/Article_7_Protocolo_sensibilidad_v0.3.md`: matriz fijada antes de ejecutar esta sensibilidad, después de observar el basal.
- `configs/sensitivity_design_v0.3.json`: todos los parámetros, semillas y decisiones de análisis.
- `tests/test_sensitivity.py`: cinco pruebas adicionales a las 24 del modelo.
- `article7/sensitivity.py`: ejecutor que conserva las reglas originales y audita todos los escenarios.
- `article7/analyze_sensitivity.py`: contraste emparejado, valoración del tiempo, diagnósticos y figuras.
- `docs/sensitivity_verification_v0.3.txt`: salida de las 29 pruebas.

Los intervalos del 95% son percentiles marginales de bootstrap por bloques de semillas, con 5.000 remuestreos. Son incertidumbre Monte Carlo condicionada a los supuestos, no incertidumbre empírica ni cobertura simultánea de todos los contrastes. No se presentan p-valores. Ordenar medias no implica superioridad universal.

El análisis varía bloques de supuestos localmente y dos condiciones conjuntas; no es una sensibilidad global ni un factorial completo. Timing de eventos, orden de reglas y otros mecanismos no se evaluaron en este bloque. El estudiante debe revisar el informe, explicar las decisiones y proponer los contrastes teóricos del manuscrito con los profesores.

El notebook facilita la reproducción en Colab. Su sintaxis se comprueba localmente y los comandos de simulación/análisis se ejecutan en Python; la interacción de carga de archivos en Colab no se valida automáticamente.
