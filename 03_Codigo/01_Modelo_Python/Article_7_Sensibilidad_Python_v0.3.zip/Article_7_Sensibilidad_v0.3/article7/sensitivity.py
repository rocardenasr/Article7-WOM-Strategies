"""Predeclared, paired sensitivity experiment; core model remains v0.2.0."""
import argparse
import contextlib
import json
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict, replace
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import pandas as pd
from .model import Config
from .experiment import run_batch


def scenario_definitions():
    k=99*.08+500*.004
    return [
        ('conversion_low','conversion',{'conversion':.15}),
        ('conversion_high','conversion',{'conversion':.35}),
        ('need_low','need',{'need_p':.15}),
        ('need_high','need',{'need_p':.45}),
        ('campaign_cost_low','campaign_cost',{'referral_cost':.5,'event_fixed':30.,'event_per_person':.5}),
        ('campaign_cost_high','campaign_cost',{'referral_cost':2.,'event_fixed':120.,'event_per_person':2.}),
        ('reward_zero','reward',{'reward':0.}),
        ('reward_low','reward',{'reward':1.}),
        ('reward_high','reward',{'reward':4.}),
        ('budget_low','budget',{'budget':600.}),
        ('budget_high','budget',{'budget':2400.}),
        ('capacity_stress','capacity',{'capacity':1}),
        ('capacity_low','capacity',{'capacity':5}),
        ('capacity_high','capacity',{'capacity':40}),
        ('segregation_high','network',{'p_out':.001,'p_in':(k-500*.001)/99}),
        ('segregation_low','network',{'p_out':.010,'p_in':(k-500*.010)/99}),
        ('acquisition_threshold_low','adaptive_acquisition',{'threshold_customers':24,'threshold_promoters':8}),
        ('acquisition_threshold_high','adaptive_acquisition',{'threshold_customers':36,'threshold_promoters':12}),
        ('activity_threshold_low','adaptive_activity',{'threshold_activity':.16}),
        ('activity_threshold_high','adaptive_activity',{'threshold_activity':.24}),
        ('evidence_threshold_low','adaptive_evidence',{'min_exposures':16}),
        ('evidence_threshold_high','adaptive_evidence',{'min_exposures':24}),
        ('high_demand_conversion','joint',{'need_p':.45,'conversion':.35}),
        ('high_demand_capacity_stress','joint',{'need_p':.45,'conversion':.35,'capacity':1}),
    ]


def design_document(base):
    c=Config(**base);c.validate()
    scenarios=[]
    for sid,family,changes in scenario_definitions():
        new=replace(c,**changes);new.validate()
        scenarios.append(dict(scenario=sid,family=family,changes=changes,config=asdict(new)))
    return dict(design_version='0.3',core_version='0.2.0',seeds=list(range(2001,2101)),
                policies=list('ABCDEFG'),replications=100,scenarios=scenarios,
                accounting_time_values=[0.,2.,4.],bootstrap_replications=5000,bootstrap_seed=730003,
                timestamp_utc=datetime.now(timezone.utc).isoformat(),baseline=base,
                approach='post-baseline prespecified one-factor-at-a-time plus two joint scenarios',
                new_runs=16800,reference_runs_reused=700,distinct_scenario_policy_seed_cases=17500)


def worker(job):
    config_path,out,first,count,log=job
    with open(log,'w',encoding='utf-8') as f,contextlib.redirect_stdout(f):
        run_batch(config_path,out,first,count)
    manifest_path=Path(out)/'experiment_manifest.json'
    manifest=json.loads(manifest_path.read_text())
    manifest['scenario']=Path(out).name
    manifest_path.write_text(json.dumps(manifest,indent=2))
    return out


def run_sensitivity(design_path,out,baseline,workers=4):
    design_path=Path(design_path); out=Path(out);baseline=Path(baseline)
    design=json.loads(design_path.read_text());
    if out.exists() and any(out.iterdir()):raise ValueError('Sensitivity output must be empty')
    out.mkdir(parents=True,exist_ok=True);(out/'logs').mkdir();(out/'configs').mkdir()
    archived=json.loads((baseline/'experiment_manifest.json').read_text())
    assert archived['config']==design['baseline']
    assert archived['seeds']==design['seeds'] and archived['policies']==design['policies']
    for name,digest in archived['source_hashes'].items():
        assert sha256((Path(__file__).parent/name).read_bytes()).hexdigest()==digest
    freeze=dict(design_sha256=sha256(design_path.read_bytes()).hexdigest(),
                runner_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
                baseline_manifest_sha256=sha256((baseline/'experiment_manifest.json').read_bytes()).hexdigest(),
                core_hashes=archived['source_hashes'],started_at=datetime.now(timezone.utc).isoformat(),
                workers=workers,planned_runs=design['new_runs'])
    (out/'frozen_design.json').write_text(json.dumps(design,indent=2))
    (out/'execution_manifest.json').write_text(json.dumps(freeze,indent=2))
    jobs=[]
    for s in design['scenarios']:
        sid=s['scenario'];path=out/'configs'/f'{sid}.json';path.write_text(json.dumps(s['config'],indent=2))
        jobs.append((str(path),str(out/sid),design['seeds'][0],len(design['seeds']),str(out/'logs'/f'{sid}.txt')))
    start=time.monotonic(); completed=[]
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures={pool.submit(worker,job):job[1] for job in jobs}
        for future in as_completed(futures):
            path=Path(future.result());completed.append(path.name)
            print(f'{len(completed)}/{len(jobs)} scenarios complete: {path.name}; {time.monotonic()-start:.1f}s',flush=True)
    summaries=[];audits=[]
    for sid,path in [('baseline',baseline)]+[(s['scenario'],out/s['scenario']) for s in design['scenarios']]:
        summary=pd.read_csv(path/'run_summary.csv');audit=pd.read_csv(path/'audit_results.csv')
        assert len(summary)==700 and len(audit)==700 and (audit.status=='passed').all()
        assert not summary.duplicated(['seed','policy']).any()
        summary.insert(0,'scenario',sid);audit.insert(0,'scenario',sid)
        summaries.append(summary);audits.append(audit)
    pd.concat(summaries,ignore_index=True).to_csv(out/'all_run_summary.csv',index=False)
    pd.concat(audits,ignore_index=True).to_csv(out/'all_audit_results.csv',index=False)
    freeze.update(completed_scenarios=len(completed),new_runs=len(completed)*700,
                  comparison_cases=17500,completed_at=datetime.now(timezone.utc).isoformat(),
                  elapsed_seconds=time.monotonic()-start)
    (out/'execution_manifest.json').write_text(json.dumps(freeze,indent=2))
    print(json.dumps(freeze),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--design',default='configs/sensitivity_design_v0.3.json')
    p.add_argument('--out',default='outputs/sensitivity_v0.3');p.add_argument('--baseline',default='outputs/main')
    p.add_argument('--workers',type=int,default=4)
    a=p.parse_args();run_sensitivity(a.design,a.out,a.baseline,a.workers)
