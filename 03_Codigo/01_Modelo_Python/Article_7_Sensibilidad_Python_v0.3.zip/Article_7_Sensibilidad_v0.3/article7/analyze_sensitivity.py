"""Paired scenario analysis, exact time valuation, diagnostics and research figures."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm

LABELS=dict(A='Organic',B='Referrals',C='Incentives',D='Events',E='Mixed',F='Sequence',G='Adaptive')
SCENARIO_LABELS={
 'baseline':'Baseline', 'conversion_low':'Conversion 0.15','conversion_high':'Conversion 0.35',
 'need_low':'Need 0.15','need_high':'Need 0.45',
 'campaign_cost_low':'Referral/event costs ×0.5','campaign_cost_high':'Referral/event costs ×2',
 'reward_zero':'Reward 0','reward_low':'Reward 1','reward_high':'Reward 4',
 'budget_low':'Budget 600','budget_high':'Budget 2400','capacity_stress':'Capacity 1',
 'capacity_low':'Capacity 5','capacity_high':'Capacity 40','segregation_high':'High segregation',
 'segregation_low':'Low segregation','acquisition_threshold_low':'Acquisition thresholds 24 / 8',
 'acquisition_threshold_high':'Acquisition thresholds 36 / 12','activity_threshold_low':'Activity threshold 0.16',
 'activity_threshold_high':'Activity threshold 0.24','evidence_threshold_low':'Evidence threshold 16',
 'evidence_threshold_high':'Evidence threshold 24','high_demand_conversion':'High need + conversion',
 'high_demand_capacity_stress':'High need + conversion; capacity 1'}


def ci(bootstrap):return np.quantile(bootstrap,[.025,.975],axis=0)


def analyze(source,baseline,out):
    source,baseline,out=map(Path,(source,baseline,out));out.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(source/'all_run_summary.csv')
    design=json.loads((source/'frozen_design.json').read_text())
    scenarios=['baseline']+[s['scenario'] for s in design['scenarios']]
    configs={'baseline':design['baseline'],**{s['scenario']:s['config'] for s in design['scenarios']}}
    seeds=design['seeds'];policies=list('ABCDEFG');n=len(seeds)
    assert len(d)==len(scenarios)*n*7 and not d.duplicated(['scenario','seed','policy']).any()
    metrics=['new_customers','profit','adjusted_profit','marketing_cost','hours','unserved','aware','events','event_links','communities_reached']
    indices=np.random.default_rng(design['bootstrap_seed']).integers(0,n,(design['bootstrap_replications'],n))
    weights=np.stack([np.bincount(row,minlength=n) for row in indices])/n
    arrays={};boots={};stats=[];pairs=[];changes=[];time_rows=[];time_pairs=[];break_even=[]
    comparisons=[(p,'A') for p in policies if p!='A']+[('G',p) for p in 'BCDEF']
    for sid in scenarios:
        arrays[sid]={};boots[sid]={}
        frame=d[d.scenario==sid]
        for metric in metrics:
            matrix=frame.pivot(index='seed',columns='policy',values=metric).loc[seeds,policies].to_numpy()
            bootstrap=weights@matrix
            arrays[sid][metric]=matrix;boots[sid][metric]=bootstrap
            lo,hi=ci(bootstrap)
            for j,p in enumerate(policies):
                stats.append(dict(scenario=sid,policy=p,metric=metric,n=n,mean=matrix[:,j].mean(),
                    sd=matrix[:,j].std(ddof=1),mcse=matrix[:,j].std(ddof=1)/np.sqrt(n),ci95_low=lo[j],ci95_high=hi[j]))
            for lhs,rhs in comparisons:
                i,j=policies.index(lhs),policies.index(rhs);delta=matrix[:,i]-matrix[:,j]
                lo_d,hi_d=ci(bootstrap[:,i]-bootstrap[:,j])
                pairs.append(dict(scenario=sid,metric=metric,comparison=lhs+'-'+rhs,n=n,
                     mean_difference=delta.mean(),mcse=delta.std(ddof=1)/np.sqrt(n),ci95_low=lo_d,ci95_high=hi_d))
            if sid!='baseline':
                delta=matrix-arrays['baseline'][metric];diffboot=bootstrap-boots['baseline'][metric]
                lo_d,hi_d=ci(diffboot)
                for j,p in enumerate(policies):
                    changes.append(dict(scenario=sid,policy=p,metric=metric,n=n,mean_change=delta[:,j].mean(),
                          mcse=delta[:,j].std(ddof=1)/np.sqrt(n),ci95_low=lo_d[j],ci95_high=hi_d[j]))
        for w in design['accounting_time_values']:
            m=arrays[sid]['profit']-w*arrays[sid]['hours'];b=boots[sid]['profit']-w*boots[sid]['hours'];lo,hi=ci(b)
            for j,p in enumerate(policies):
                time_rows.append(dict(scenario=sid,time_value=w,policy=p,mean=m[:,j].mean(),ci95_low=lo[j],ci95_high=hi[j]))
            for lhs,rhs in comparisons:
                i,j=policies.index(lhs),policies.index(rhs);low,high=ci(b[:,i]-b[:,j])
                time_pairs.append(dict(scenario=sid,time_value=w,comparison=lhs+'-'+rhs,
                    mean_difference=(m[:,i]-m[:,j]).mean(),ci95_low=low,ci95_high=high))
        for j,p in enumerate(policies[1:],start=1):
            dp=arrays[sid]['profit'][:,j]-arrays[sid]['profit'][:,0]
            dh=arrays[sid]['hours'][:,j]-arrays[sid]['hours'][:,0]
            dbp=boots[sid]['profit'][:,j]-boots[sid]['profit'][:,0]
            dbh=boots[sid]['hours'][:,j]-boots[sid]['hours'][:,0]
            valid=dbh>0
            threshold=dp.mean()/dh.mean() if dh.mean()>0 else np.nan
            low,high=ci(dbp[valid]/dbh[valid]) if valid.any() else (np.nan,np.nan)
            break_even.append(dict(scenario=sid,policy=p,mean_profit_difference=dp.mean(),mean_hours_difference=dh.mean(),
                  break_even_time_value=threshold,ci95_low=low,ci95_high=high,valid_bootstrap=int(valid.sum()),
                  interpretation='conditional ratio of paired mean differences; not empirical optimum'))
    for name,rows in [('policy_summary',stats),('paired_policy_contrasts',pairs),('paired_changes_from_baseline',changes),
                      ('time_value_summary',time_rows),('time_value_contrasts',time_pairs),('time_break_even',break_even)]:
        pd.DataFrame(rows).to_csv(out/(name+'.csv'),index=False)
    diagnostic=[];action_rows=[];byrun=[]
    for sid in scenarios:
        folder=baseline if sid=='baseline' else source/sid
        dec=pd.read_csv(folder/'decisions.csv');period=pd.read_csv(folder/'period_results.csv')
        g=dec[dec.policy=='G'];cfg=configs[sid];counts=g.action.value_counts()
        for action in ['referral','incentive','event','hold_event','pause']:
            action_rows.append(dict(scenario=sid,action=action,months=int(counts.get(action,0)),share=counts.get(action,0)/len(g)))
        inc_runs=int(g[g.action=='incentive'].seed.nunique());event_runs=int(g[g.action=='event'].seed.nunique())
        gframe=d[(d.scenario==sid)&(d.policy=='G')]
        true_incentive=blocked_by_referrals=0
        for row in g.itertuples():
            o=json.loads(row.observable)
            cond=(o['history_months']>=cfg['window'] and o['A3'] is not None and
                  o['A3']<cfg['threshold_activity'] and o['exposures_window']>=cfg['min_exposures'] and
                  o['R3'] is not None and o['R3']<cfg['threshold_redundancy'])
            true_incentive+=cond;blocked_by_referrals+=cond and row.rule==4
        for seed in seeds:
            perseed=g[g.seed==seed]
            for action in ['referral','incentive','event','hold_event','pause']:
                byrun.append(dict(scenario=sid,seed=seed,action=action,months=int((perseed.action==action).sum())))
        perpolicy=d[d.scenario==sid].groupby('policy')
        diagnostic.append(dict(scenario=sid,customers_top_mean=perpolicy.new_customers.mean().idxmax(),
             adjusted_profit_top_mean=perpolicy.adjusted_profit.mean().idxmax(),
             operating_profit_top_mean=perpolicy.profit.mean().idxmax(),
             max_customers_mean=float(perpolicy.new_customers.mean().max()),
             g_customers=gframe.new_customers.mean(),g_adjusted_profit=gframe.adjusted_profit.mean(),
             g_incentive_months=int(counts.get('incentive',0)),g_incentive_runs=inc_runs,
             g_event_months=int(counts.get('event',0)),g_event_runs=event_runs,
             g_incentive_conditions_true=int(true_incentive),g_incentive_blocked_by_acquisition=int(blocked_by_referrals),
             total_unserved=int(period.unserved.sum()),runs_with_unserved=int(d[d.scenario==sid].unserved.gt(0).sum()),
             max_monthly_sales=int(period.sales.max()),
             max_capacity_use=float((period.sales/period.capacity).max()),
             g_capacity_pause_months=int((g.rule==2).sum())))
    diag=pd.DataFrame(diagnostic);diag.to_csv(out/'scenario_diagnostics.csv',index=False)
    actions=pd.DataFrame(action_rows);actions.to_csv(out/'adaptive_action_counts.csv',index=False)
    pd.DataFrame(byrun).to_csv(out/'adaptive_actions_by_replication.csv',index=False)
    figdir=out/'figures';figdir.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    fig,axes=plt.subplots(1,2,figsize=(12.5,10),layout='constrained')
    for ax,metric,title in zip(axes,['new_customers','adjusted_profit'],['New customers: difference vs. organic','Adjusted profit: difference vs. organic (UM)']):
        matrix=np.array([arrays[s][metric].mean(axis=0)[1:]-arrays[s][metric].mean(axis=0)[0] for s in scenarios])
        norm=TwoSlopeNorm(vmin=min(float(matrix.min()),-.1),vcenter=0,vmax=max(float(matrix.max()),.1))
        im=ax.imshow(matrix,aspect='auto',cmap='RdBu',norm=norm)
        ax.set_xticks(range(6),[f'{p}: {LABELS[p]}' for p in 'BCDEFG'],rotation=45,ha='right',fontsize=9);ax.set_yticks(range(len(scenarios)),[SCENARIO_LABELS[s] for s in scenarios])
        ax.set_title(title,fontweight='bold')
        for i in range(len(scenarios)):
            for j in range(6):
                val=matrix[i,j];color='white' if norm(val)<.23 or norm(val)>.80 else '#222'
                ax.text(j,i,f'{val:.1f}' if metric=='new_customers' else f'{val:.0f}',ha='center',va='center',fontsize=7,color=color)
        fig.colorbar(im,ax=ax,shrink=.5,pad=.02)
    fig.suptitle('Article 7 · Prespecified sensitivity scenarios\nPaired mean differences; 100 seeds per scenario; time value = 2 UM/hour',fontsize=12)
    fig.savefig(figdir/'scenario_policy_differences.png',dpi=180);fig.savefig(figdir/'scenario_policy_differences.svg');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12,9),layout='constrained')
    bottom=np.zeros(len(scenarios));acols={'referral':'#467DA6','incentive':'#A37F3B','event':'#8262A4','hold_event':'#B9A5D0','pause':'#C1C8CD'}
    for action,color in acols.items():
        vals=actions[actions.action==action].set_index('scenario').loc[scenarios,'share'].to_numpy()
        axes[0].barh(range(len(scenarios)),vals,left=bottom,label=action,color=color);bottom+=vals
    axes[0].set_yticks(range(len(scenarios)),[SCENARIO_LABELS[s] for s in scenarios]);axes[0].invert_yaxis()
    axes[0].set(title='Actions selected by adaptive policy',xlabel='Share of 6,000 simulated months',xlim=(0,1))
    axes[0].legend(fontsize=8,loc='lower center',bbox_to_anchor=(.5,1.04),ncol=3)
    w=np.linspace(0,4,161);colors=['#3F6670','#467DA6','#A37F3B','#8262A4','#B56A54','#578A70','#C04F5E']
    for j,p in enumerate(policies):
        values=arrays['baseline']['profit'][:,j].mean()-w*arrays['baseline']['hours'][:,j].mean()
        axes[1].plot(w,values,label=f'{p}: {LABELS[p]}',color=colors[j],lw=1.8)
    axes[1].axhline(0,color='#aaa',lw=.7);axes[1].axvline(2,color='#aaa',ls='--',lw=.8)
    axes[1].set(title='Baseline: accounting value of marketing time',xlabel='Time value (illustrative UM/hour)',ylabel='Mean adjusted profit (UM)')
    axes[1].legend(fontsize=8);axes[1].grid(alpha=.2)
    fig.savefig(figdir/'adaptive_actions_and_time_value.png',dpi=180);fig.savefig(figdir/'adaptive_actions_and_time_value.svg');plt.close(fig)
    meta=dict(new_simulations=16800,baseline_reused=700,comparison_cases=17500,bootstrap_replications=5000,
              seed=730003,unit='seed block shared across policies and scenarios',
              intervals='marginal percentile 95%; no simultaneous coverage or global sensitivity claim',
              accounting_evaluations=52500)
    (out/'analysis_manifest.json').write_text(json.dumps(meta,indent=2))
    print(diag.to_string(index=False))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',default='outputs/sensitivity_v0.3')
    p.add_argument('--baseline',default='outputs/main');p.add_argument('--out',default='outputs/sensitivity_analysis_v0.3')
    a=p.parse_args();analyze(a.source,a.baseline,a.out)
