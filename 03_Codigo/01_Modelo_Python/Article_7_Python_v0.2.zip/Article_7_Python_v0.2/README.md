# Article 7 — WOM ABM en Python · v0.2.0

Modelo teórico basado en agentes de referidos, incentivos y eventos. Todos los parámetros son ilustrativos; no hay calibración empírica. Implementa la especificación v0.1 y la adenda Python v0.2.

## Inicio

Utilice Python 3.10 o superior. El entorno exacto usado queda registrado en los manifiestos y en `requirements-tested.txt`.

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m article7.experiment --out outputs/pilot --first-seed 1001 --replications 10
python -m article7.experiment --out outputs/main --first-seed 2001 --replications 100
python -m article7.analyze --source outputs/main --out outputs/analysis
```

Los comandos se ejecutan desde la carpeta que contiene este README. Los directorios de experimentos deben estar vacíos. Para repetir una corrida, seleccione otro directorio de salida. El notebook `Article_7_Colab_v0.2.ipynb` facilita cargar este ZIP en Google Colab y ejecutar los mismos comandos.

## Archivos

- `article7/model.py`: agentes, red, intervenciones, contabilidad, decisiones y agenda mensual.
- `article7/experiment.py`: ejecución emparejada, auditoría y exportación.
- `article7/analyze.py`: tablas, diferencias emparejadas, intervalos Monte Carlo y figuras.
- `configs/baseline.json`: parámetros del escenario basal.
- `tests/test_model.py`: 20 casos de v0.1 y cuatro pruebas adicionales.
- `docs/`: especificación, adenda y decisiones de implementación.

Políticas: A orgánica; B referidos; C incentivos; D eventos; E mezcla; F secuencia; G adaptativa. Todas incluyen WOM orgánico. La capacidad de servicio se separa de las horas de marketing; no hay recompra ni reinversión automática.

## Resultados y reproducción

Cada experimento contiene configuración, versiones, SHA-256 del código, semillas y un manifiesto de ejecuciones. `initial_conditions/` contiene red y agentes compartidos por semilla; `traces/` contiene solicitudes, ofertas, recomendaciones, exposiciones/ventas, eventos y enlaces. Las series y decisiones están en archivos agregados. Una semilla identifica una repetición emparejada, no una observación empírica.

El ZIP de código no incluye los resultados completos; estos se entregan en paquetes separados para piloto y escenario principal. Puede extraerlos en `outputs/pilot` y `outputs/main` para reproducir el análisis sin simular otra vez.

Las tablas de análisis muestran intervalos percentiles del 95% obtenidos con 5.000 remuestreos de repeticiones completas. Son intervalos marginales de incertidumbre Monte Carlo condicionados a los supuestos, no intervalos empíricos ni simultáneos de todos los contrastes. No se hacen pruebas de significancia.

## Próximo trabajo científico

Revisar sensibilidad de conversión, costos, presupuesto, estructura, capacidad y umbrales. La ausencia de una acción en G debe informarse y diagnosticarse. No modificar reglas solo para hacer ganar a G. El estudiante deberá explicar el mecanismo, reproducir al menos una trayectoria, revisar el código y desarrollar la interpretación y el primer borrador con supervisión.
