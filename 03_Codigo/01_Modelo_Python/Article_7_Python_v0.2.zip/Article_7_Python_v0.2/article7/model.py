"""ABM implementing Article 7 specification v0.1 and Python addendum v0.2.

Only NumPy is required by the simulation. Random draws are keyed by seed,
month, mechanism and agent, never by policy or mutable generator position.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from hashlib import blake2b, sha256
from collections import defaultdict
import json
import math
import numpy as np

POLICIES = dict(A="Organica", B="Referidos", C="Incentivos", D="Eventos",
                E="Mezcla", F="Secuencia", G="Adaptativa")
CHANNELS = ("referral", "incentive", "event")
EPS = 1e-9


@dataclass(frozen=True)
class Config:
    n: int = 600
    communities: int = 6
    months: int = 60
    initial_customers: int = 15
    initial_promoters: int = 6
    p_in: float = .08
    p_out: float = .004
    fit_low: float = .20
    fit_high: float = 1.
    initial_fit_min: float = .60
    need_p: float = .30
    conversion: float = .25
    satisfied_p: float = .80
    willing_p: float = .40
    budget: float = 1200.
    hours: float = 40.
    capacity: int = 20
    price: float = 20.
    service_cost: float = 12.
    time_cost: float = 2.
    energy_initial: float = 1.
    energy_cost: float = .10
    energy_recovery: float = .05
    organic_p: float = .25
    referral_max: int = 12
    referral_response: float = .60
    referral_cost: float = 1.
    referral_hours: float = .50
    referral_bonus: float = .15
    referral_targeting: float = 1.
    incentive_max: int = 20
    reward: float = 2.
    incentive_hours: float = .10
    incentive_gain: float = .50
    incentive_half: float = 2.
    incentive_energy: float = .20
    event_fixed: float = 60.
    event_per_person: float = 1.
    event_invites: int = 60
    event_capacity: int = 30
    event_attendance: float = .60
    event_min_links: int = 6
    event_p_cross: float = .10
    event_p_within: float = .02
    event_prep_hours: float = 8.
    event_base_hours: float = 2.
    event_per_person_hours: float = .10
    event_interval: int = 6
    sequence_ref_end: int = 20
    sequence_inc_end: int = 40
    mixed_ref: float = .40
    mixed_inc: float = .30
    mixed_event: float = .30
    window: int = 3
    min_exposures: int = 20
    threshold_customers: int = 30
    threshold_promoters: int = 10
    threshold_utilization: float = .90
    threshold_redundancy: float = .60
    threshold_activity: float = .20
    threshold_marginal: float = .25
    threshold_communities: int = 2
    threshold_invites: int = 10
    campaigns_enabled: bool = True

    def validate(self):
        if self.n < 1 or self.communities < 1 or self.n % self.communities:
            raise ValueError("n must be positive and divisible by communities")
        if not 0 <= self.initial_promoters <= self.initial_customers <= self.n // self.communities:
            raise ValueError("Invalid initial customer/promoter counts")
        if self.months < 1 or self.window < 1 or self.event_interval < 2:
            raise ValueError("Invalid horizon/window/event interval")
        for k in ("n", "communities", "months", "initial_customers", "initial_promoters", "capacity",
                  "referral_max", "incentive_max", "event_invites", "event_capacity", "event_min_links",
                  "event_interval", "sequence_ref_end", "sequence_inc_end", "window", "min_exposures",
                  "threshold_customers", "threshold_promoters", "threshold_communities", "threshold_invites"):
            v = getattr(self, k)
            if type(v) is not int or v < 0:
                raise ValueError(f"Invalid integer {k}")
        for k, v in asdict(self).items():
            if isinstance(v, (int, float)) and (not math.isfinite(v) or v < 0):
                raise ValueError(f"Invalid nonnegative parameter {k}")
        for k in ("p_in", "p_out", "need_p", "satisfied_p", "willing_p", "organic_p", "referral_response",
                  "event_attendance", "event_p_cross", "event_p_within", "energy_initial",
                  "threshold_utilization", "threshold_redundancy", "threshold_activity", "threshold_marginal"):
            if getattr(self, k) > 1:
                raise ValueError(f"Probability outside [0,1]: {k}")
        if not 0 <= self.fit_low <= self.fit_high <= 1 or self.energy_cost > 1:
            raise ValueError("Invalid fit or energy range")
        if self.initial_customers and self.initial_fit_min >= self.fit_high and self.fit_low < self.fit_high:
            raise ValueError("No positive probability of initial fit eligibility")
        if self.initial_customers and self.fit_high < self.initial_fit_min:
            raise ValueError("No eligible initial fits")
        if not math.isclose(self.mixed_ref + self.mixed_inc + self.mixed_event, 1):
            raise ValueError("Mixed shares must sum to one")
        if self.incentive_half <= 0 or self.sequence_ref_end > self.sequence_inc_end:
            raise ValueError("Invalid incentive constant or sequence")


def uniform(seed: int, stream: int, month: int = 0, *keys: int) -> float:
    """Stable 53-bit uniform; no Python hash() and no policy key."""
    data = ("article7-v02|" + "|".join(map(str, (seed, stream, month, *keys)))).encode()
    bits = int.from_bytes(blake2b(data, digest_size=8).digest(), "big") >> 11
    return bits / 2**53


def ratio(n, d):
    return n / d if d else None


def network_stats(adj, community):
    n = len(adj)
    deg = np.array([len(x) for x in adj])
    edges = [(i, j) for i in range(n) for j in adj[i] if i < j]
    m = len(edges)
    seen, sizes = set(), []
    for root in range(n):
        if root in seen:
            continue
        stack, size = [root], 0
        seen.add(root)
        while stack:
            i = stack.pop(); size += 1
            for j in adj[i] - seen:
                seen.add(j); stack.append(j)
        sizes.append(size)
    cluster = []
    for i, nei in enumerate(adj):
        k = len(nei)
        tri2 = sum(len(nei & adj[j]) for j in nei)
        cluster.append(tri2 / (k * (k - 1)) if k > 1 else 0.)
    cross = sum(community[i] != community[j] for i, j in edges)
    modularity = 0.
    if m:
        for c in sorted(set(community)):
            internal = sum(community[i] == c == community[j] for i, j in edges)
            dc = sum(deg[community == c])
            modularity += internal / m - (dc / (2*m))**2
    return dict(edges=m, mean_degree=float(deg.mean()), components=len(sizes),
                largest_component=max(sizes), clustering=float(np.mean(cluster)),
                modularity=float(modularity) if m else None, cross_share=ratio(cross, m))


def make_initial(c: Config, seed: int):
    c.validate()
    if type(seed) is not int or seed < 0:
        raise ValueError("seed must be a nonnegative integer")
    n = c.n
    community = np.repeat(np.arange(c.communities), n // c.communities)
    rng = lambda stream: np.random.Generator(np.random.PCG64(np.random.SeedSequence([seed, stream])))
    i, j = np.triu_indices(n, 1)
    edge_mask = rng(0).random(len(i)) < np.where(community[i] == community[j], c.p_in, c.p_out)
    adj = [set() for _ in range(n)]
    for a, b in zip(i[edge_mask], j[edge_mask]):
        adj[int(a)].add(int(b)); adj[int(b)].add(int(a))
    fits = rng(1).uniform(c.fit_low, c.fit_high, n)
    retries = 0
    while np.sum((community == 0) & (fits >= c.initial_fit_min)) < c.initial_customers:
        retries += 1
        if retries > 10000:
            raise ValueError("Cannot initialize eligible customers after 10000 redraws")
        fits[community == 0] = rng(10000 + retries).uniform(c.fit_low, c.fit_high, n // c.communities)
    customer = np.zeros(n, dtype=bool)
    candidates = np.flatnonzero((community == 0) & (fits >= c.initial_fit_min))
    ids = rng(2).permutation(candidates)[:c.initial_customers]
    customer[ids] = True
    satisfied = rng(3).random(n) < c.satisfied_p
    willing = rng(4).random(n) < c.willing_p
    satisfied[ids] = True; willing[ids] = False
    willing[rng(5).permutation(ids)[:c.initial_promoters]] = True
    return dict(adj=adj, community=community, fit=fits, customer=customer,
                satisfied=satisfied, willing=willing, fit_redraws=retries,
                diagnostics=network_stats(adj, community))


def adaptive_action(c, obs, feasible, pending):
    """Pure decision rule. Receives observable scalars, never agent/world state."""
    skipped = []
    if pending:
        return "hold_event", 1, skipped
    if c.capacity == 0 or (obs["U3"] is not None and obs["U3"] >= c.threshold_utilization):
        return "pause", 2, skipped
    if obs["C"] >= c.n or not any(feasible.values()):
        return "pause", 3, skipped
    rules = [
        (4, obs["C"] < c.threshold_customers or obs["P"] < c.threshold_promoters, "referral"),
        (5, obs["exposures_window"] >= c.min_exposures and
         ((obs["R3"] is not None and obs["R3"] >= c.threshold_redundancy) or
          obs["Gobs"] <= c.threshold_communities), "event"),
        (6, obs["history_months"] >= c.window and obs["A3"] is not None and
         obs["A3"] < c.threshold_activity and obs["exposures_window"] >= c.min_exposures and
         obs["R3"] is not None and obs["R3"] < c.threshold_redundancy, "incentive"),
        (7, obs["history_months"] < c.window or
         (obs["M3"] is not None and obs["M3"] >= c.threshold_marginal and
          obs["exposures_window"] >= c.min_exposures), "referral")]
    for priority, condition, action in rules:
        if condition:
            if feasible[action]:
                return action, priority, skipped
            skipped.append(dict(priority=priority, action=action, reason="infeasible"))
    return "pause", 8, skipped


class Model:
    def __init__(self, config=Config(), seed=1001, policy="A", initial=None):
        config.validate()
        if policy not in POLICIES:
            raise ValueError("Unknown policy")
        self.c, self.seed, self.policy = config, seed, policy
        self.run_id = f"s{seed}_{policy}"
        init = make_initial(config, seed) if initial is None else initial
        self.initial = init
        self.adj = [set(x) for x in init["adj"]]
        for k in ("community", "fit", "customer", "satisfied", "willing"):
            setattr(self, k, init[k].copy())
        self.aware = self.customer.copy()
        self.energy = np.where(self.customer, config.energy_initial, 0.)
        self.purchase_month = np.where(self.customer, 0, -1)
        self.source = np.where(self.customer, "initial", "").astype(object)
        self.referred = set()
        self.unserved_people = set()
        self.logs = {k: [] for k in ("period_results", "decisions", "referral_requests", "incentive_offers",
                                     "recommendations", "exposures_and_sales", "events", "event_links")}
        self.spent = dict.fromkeys(CHANNELS, 0.)
        self.reserved = dict.fromkeys(CHANNELS, 0.)
        self.total_hours = 0.
        self.pending = None
        self.last_event_prep = -config.event_interval
        self.month = 0

    def u(self, stream, *keys):
        return uniform(self.seed, stream, self.month, *map(int, keys))

    def emit_log(self, table, row):
        self.logs[table].append(dict(run_id=self.run_id, seed=self.seed, policy=self.policy, month=self.month, **row))

    def remaining(self, channel):
        if self.policy == "E":
            share = dict(zip(CHANNELS, (self.c.mixed_ref, self.c.mixed_inc, self.c.mixed_event)))[channel]
            return self.c.budget * share - self.spent[channel] - self.reserved[channel]
        return self.c.budget - sum(self.spent.values()) - sum(self.reserved.values())

    def hour_limit(self, channel):
        share = dict(zip(CHANNELS, (self.c.mixed_ref, self.c.mixed_inc, self.c.mixed_event)))[channel]
        return self.c.hours * (share if self.policy == "E" else 1.)

    def hours_left(self, channel):
        used = self.hours[channel] if self.policy == "E" else sum(self.hours.values())
        reserved = self.pending_hours if channel == "event" or self.policy != "E" else 0.
        return self.hour_limit(channel) - used - reserved

    def affordable(self, channel, cost, hours):
        return self.remaining(channel) + EPS >= cost and self.hours_left(channel) + EPS >= hours

    def promoters(self):
        return np.flatnonzero(self.customer & self.satisfied & self.willing)

    def observable(self):
        h = self.logs["period_results"][-self.c.window:]
        expo = sum(x["exposures"] for x in h)
        red = ratio(sum(x["repeated_exposures"] for x in h), expo)
        return dict(C=int(self.customer.sum()), P=len(self.promoters()),
                    U3=ratio(sum(x["sales"] for x in h), sum(x["capacity"] for x in h)),
                    A3=ratio(sum(x["active_promoters"] for x in h), sum(x["promoters_start"] for x in h)),
                    R3=red, M3=1-red if red is not None else None,
                    Gobs=len(set(self.community[self.aware])), exposures_window=expo, history_months=len(h))

    def invitation_list(self):
        invited = set(map(int, np.flatnonzero(self.customer)))
        for i in sorted(invited):
            candidates = sorted(j for j in self.adj[i] if not self.customer[j])
            if candidates:
                invited.add(candidates[int(self.u(30, i) * len(candidates))])
        return sorted(invited, key=lambda i: (self.u(31, i), i))[:self.c.event_invites]

    def feasibility(self, invitations, adaptive=False):
        c = self.c
        req = bool(np.any(self.customer & self.satisfied)) and c.referral_max > 0
        inc = len(self.promoters()) > 0 and c.incentive_max > 0 and c.reward > 0
        event = (self.pending is None and self.month < c.months and
                 self.month - self.last_event_prep >= c.event_interval and
                 len(invitations) >= (c.threshold_invites if adaptive else 1) and
                 self.hour_limit("event") + EPS >= c.event_base_hours + c.event_per_person_hours*c.event_capacity)
        return dict(referral=req and self.affordable("referral", c.referral_cost, c.referral_hours),
                    incentive=inc and self.affordable("incentive", c.reward, c.incentive_hours),
                    event=event and self.affordable("event", c.event_fixed+c.event_capacity*c.event_per_person, c.event_prep_hours))

    def choose(self, feasible):
        c, t, p = self.c, self.month, self.policy
        obs = self.observable()
        if not c.campaigns_enabled:
            action, rule, skipped = "pause", 0, []
        elif p == "G":
            action, rule, skipped = adaptive_action(c, obs, feasible, self.pending is not None)
        else:
            skipped, rule = [], 0
            scheduled = (t-1) % c.event_interval == 0
            action = {"A": "pause", "B": "referral", "C": "incentive"}.get(p, "pause")
            if p == "D": action = "event" if scheduled else "pause"
            if p == "E": action = "mixed_event" if scheduled else "mixed"
            if p == "F":
                action = ("referral" if t <= c.sequence_ref_end else "incentive" if t <= c.sequence_inc_end else
                          "event" if (t-c.sequence_inc_end-1) % c.event_interval == 0 else "pause")
        self.emit_log("decisions", dict(action=action, rule=rule, observable=obs, feasible=feasible,
                      skipped=skipped, pending=self.pending is not None,
                      free_budget=self.c.budget-sum(self.spent.values())-sum(self.reserved.values())))
        actions = (set(CHANNELS) if action == "mixed_event" else {"referral", "incentive"} if action == "mixed" else {action})
        return action, actions

    def expose(self, i, j, kind, offer=False, additional=False, request_id="", event_id="", before=None):
        mech = {"referral": 1, "organic": 2, "incentive": 2, "event": 3}[kind]
        eid = f"{self.month}:{mech}:{i}:{j}"
        e = dict(exposure_id=eid, sender=int(i), receiver=int(j), kind=kind, mechanism=mech,
                 offer=bool(offer), additional=bool(additional), request_id=request_id, event_id=event_id,
                 repeated=False, decisive=False, need=False, purchase_decision=False, served=False, reward_paid=0.)
        self.exposures.append(e)
        if kind != "event":
            self.emit_log("recommendations", dict(exposure_id=eid, sender=int(i), receiver=int(j), kind=kind,
                          offer=bool(offer), additional=bool(additional), energy_before=float(before),
                          energy_after=float(self.energy[i]), request_id=request_id))

    def referrals(self):
        c = self.c
        candidates = sorted(map(int, np.flatnonzero(self.customer & self.satisfied)), key=lambda i: (self.u(10,i),i))
        for i in candidates[:c.referral_max]:
            if not self.affordable("referral", c.referral_cost, c.referral_hours): break
            self.spent["referral"] += c.referral_cost; self.hours["referral"] += c.referral_hours
            rid = f"{self.month}:request:{i}"
            valid = sorted(j for j in self.adj[i] if not self.customer[j] and (i,j) not in self.referred)
            reason, target = "declined", -1
            if self.energy[i] + EPS < c.energy_cost: reason = "low_energy"
            elif not valid: reason = "no_contacts"
            elif self.u(11,i) < c.referral_response:
                weights = np.array([1+c.referral_targeting*self.fit[j] for j in valid])
                idx = min(len(valid)-1, int(np.searchsorted(np.cumsum(weights), self.u(12,i)*weights.sum(), side="right")))
                target = valid[idx]; reason = "emitted"
                before = self.energy[i]; self.energy[i] = max(0., before-c.energy_cost)
                self.referred.add((i,target))
                self.expose(i,target,"referral", request_id=rid,before=before)
            self.emit_log("referral_requests",dict(request_id=rid,sender=i,receiver=target,reason=reason,
                          cost=c.referral_cost,hours=c.referral_hours))

    def spontaneous(self, incentives):
        c = self.c
        offers = {}
        candidates = list(map(int, self.promoters()))
        if incentives and c.reward > 0:
            for i in sorted(candidates,key=lambda i:(self.u(13,i),i))[:c.incentive_max]:
                if not self.affordable("incentive", c.reward, c.incentive_hours): break
                self.reserved["incentive"] += c.reward; self.hours["incentive"] += c.incentive_hours
                offers[i] = dict(promoter=i, reward=c.reward, hours=c.incentive_hours, emitted=False,
                                 additional=False, paid=0., released=0.)
        active = 0
        for i in candidates:
            if self.energy[i]+EPS < c.energy_cost: continue
            valid = sorted(j for j in self.adj[i] if not self.customer[j])
            if not valid: continue
            basal = min(1.,c.organic_p*self.energy[i])
            boosted = min(1., (c.organic_p + (c.incentive_gain*c.reward/(c.reward+c.incentive_half) if i in offers else 0))*self.energy[i])
            u = self.u(14,i)
            if u >= boosted: continue
            j = valid[int(self.u(15,i)*len(valid))]
            before = self.energy[i]; self.energy[i] = max(0., before-c.energy_cost)
            additional = u >= basal
            if i in offers: offers[i].update(emitted=True,additional=additional)
            self.expose(i,j,"incentive" if i in offers else "organic",offer=i in offers,additional=additional,before=before)
            active += 1
        return offers, active

    def prepare_event(self, invitations):
        c = self.c
        self.spent["event"] += c.event_fixed
        self.reserved["event"] += c.event_capacity*c.event_per_person
        self.hours["event"] += c.event_prep_hours
        self.pending = dict(event_id=f"event:{self.month}",prep_month=self.month,hold_month=self.month+1,invited=invitations)
        self.last_event_prep = self.month
        self.emit_log("events",dict(**self.pending,status="prepared",attendees=[],new_links=0,cross_links=0,
                      cost=c.event_fixed,hours=c.event_prep_hours,reserved_money=self.reserved["event"],
                      reserved_hours=c.event_base_hours+c.event_per_person_hours*c.event_capacity))

    def hold_event(self):
        c, event = self.c, self.pending
        if event is None or event["hold_month"] != self.month: return []
        accepted = [i for i in event["invited"] if self.u(32,i) < c.event_attendance]
        attendees = sorted(accepted,key=lambda i:(self.u(33,i),i))[:c.event_capacity]
        cost = len(attendees)*c.event_per_person
        self.reserved["event"] = 0.; self.spent["event"] += cost
        self.pending_hours = 0.
        self.hours["event"] += c.event_base_hours+c.event_per_person_hours*len(attendees)
        for j in attendees:
            if not self.customer[j]: self.expose(-1,j,"event",event_id=event["event_id"])
        links = []
        if len(attendees) >= c.event_min_links:
            for a,i in enumerate(sorted(attendees)):
                for j in sorted(attendees)[a+1:]:
                    cross = self.community[i] != self.community[j]
                    if j not in self.adj[i] and self.u(34,i,j) < (c.event_p_cross if cross else c.event_p_within):
                        links.append((i,j))
                        self.emit_log("event_links",dict(event_id=event["event_id"],i=i,j=j,cross=bool(cross)))
        self.emit_log("events",dict(**event,status="held",attendees=attendees,new_links=len(links),
                      cross_links=sum(self.community[i]!=self.community[j] for i,j in links),cost=cost,
                      hours=c.event_base_hours+c.event_per_person_hours*len(attendees),reserved_money=0.,reserved_hours=0.))
        self.pending = None
        return links

    def settle_exposures(self, offers):
        c = self.c
        by_person = defaultdict(list)
        ordered = sorted(self.exposures, key=lambda e: (self.u(20,e["mechanism"],e["sender"],e["receiver"]),e["exposure_id"]))
        for e in ordered:
            j = e["receiver"]
            e["repeated"] = bool(self.aware[j]); self.aware[j] = True
            e["need"] = self.u(21,j) < c.need_p
            by_person[j].append(e)
        decisions = {}
        for j, exposures in by_person.items():
            decisive = min(exposures,key=lambda e:(self.u(22,e["mechanism"],e["sender"],j),e["exposure_id"]))
            decisive["decisive"] = True
            p = min(1.,self.fit[j]*(c.conversion+(c.referral_bonus if decisive["kind"]=="referral" else 0)))
            if decisive["need"] and self.u(23,j) < p:
                decisive["purchase_decision"] = True; decisions[j] = decisive
        served = sorted(decisions,key=lambda j:(self.u(24,j),j))[:c.capacity]
        for j in served:
            e = decisions[j]; e["served"] = True
            self.customer[j] = True; self.purchase_month[j] = self.month; self.source[j] = e["kind"]
            self.energy[j] = c.energy_initial
            if e["offer"]:
                i = e["sender"]
                assert i in offers
                offers[i]["paid"] += c.reward; e["reward_paid"] = c.reward
                self.spent["incentive"] += c.reward
                self.energy[i] = min(1.,self.energy[i]+c.incentive_energy*c.reward/(c.reward+c.incentive_half))
        for i,row in offers.items():
            row["released"] = row["reward"]-row["paid"]
            assert row["released"] >= -EPS
            self.emit_log("incentive_offers",row)
        self.reserved["incentive"] = 0.
        self.unserved_people.update(set(decisions)-set(served))
        for e in ordered: self.emit_log("exposures_and_sales",e)
        return len(decisions), len(served)

    def step(self):
        c = self.c
        self.month += 1
        if self.month > c.months: raise ValueError("Horizon exceeded")
        self.hours = dict.fromkeys(CHANNELS,0.)
        self.pending_hours = (c.event_base_hours+c.event_per_person_hours*c.event_capacity) if self.pending else 0.
        self.exposures = []
        old_spent = self.spent.copy()
        start_promoters = len(self.promoters())
        invitations = self.invitation_list()
        feasible = self.feasibility(invitations, self.policy=="G")
        action, actions = self.choose(feasible)
        if "event" in actions and feasible["event"]: self.prepare_event(invitations)
        if "referral" in actions: self.referrals()
        offers, active = self.spontaneous("incentive" in actions)
        links = self.hold_event()
        demand, sales = self.settle_exposures(offers)
        self.energy[self.customer] = np.minimum(1.,self.energy[self.customer]+c.energy_recovery)
        for i,j in links: self.adj[i].add(j); self.adj[j].add(i)
        cost = {k:self.spent[k]-old_spent[k] for k in CHANNELS}
        total = sum(cost.values()); hours = sum(self.hours.values()); self.total_hours += hours
        revenue = sales*c.price; service = sales*c.service_cost
        cum_sales = int(self.customer.sum())-c.initial_customers
        repeated = sum(e["repeated"] for e in self.exposures)
        row = dict(action=action,customers=int(self.customer.sum()),new_customers=cum_sales,
                   promoters_start=start_promoters,promoters_end=len(self.promoters()),active_promoters=active,
                   mean_promoter_energy=float(self.energy[self.promoters()].mean()) if len(self.promoters()) else None,
                   exposures=len(self.exposures),repeated_exposures=repeated,new_reach=len(self.exposures)-repeated,
                   redundancy=ratio(repeated,len(self.exposures)),aware=int(self.aware.sum()),
                   communities_reached=len(set(self.community[self.aware])),
                   communities_customers=len(set(self.community[self.customer])),
                   informed_by_community=[int(sum(self.aware & (self.community==k))) for k in range(c.communities)],
                   demand=demand,sales=sales,unserved=demand-sales,unserved_unique=len(self.unserved_people),capacity=c.capacity,
                   revenue=revenue,service_cost=service,referral_cost=cost["referral"],incentive_cost=cost["incentive"],
                   event_cost=cost["event"],marketing_cost=total,marketing_cost_cum=sum(self.spent.values()),
                   hours=hours,hours_by_channel=self.hours.copy(),hours_cum=self.total_hours,
                   profit=revenue-service-total,adjusted_profit=revenue-service-total-c.time_cost*hours,
                   profit_cum=cum_sales*(c.price-c.service_cost)-sum(self.spent.values()),
                   adjusted_profit_cum=cum_sales*(c.price-c.service_cost)-sum(self.spent.values())-c.time_cost*self.total_hours,
                   reserves=sum(self.reserved.values()),free_budget=c.budget-sum(self.spent.values())-sum(self.reserved.values()),
                   cash=c.budget+cum_sales*(c.price-c.service_cost)-sum(self.spent.values()),
                   edges=sum(map(len,self.adj))//2,event_links=len(links))
        self.emit_log("period_results",row)
        self.check_invariants()

    def check_invariants(self):
        c = self.c; row = self.logs["period_results"][-1]
        assert row["free_budget"] >= -EPS
        assert row["hours"] <= c.hours+EPS and row["sales"] <= c.capacity
        assert np.all(self.energy >= -EPS) and np.all(self.energy <= 1+EPS)
        assert np.all(~self.customer | self.aware)
        assert math.isclose(c.budget,row["marketing_cost_cum"]+row["reserves"]+row["free_budget"],abs_tol=EPS)
        assert math.isclose(row["cash"],c.budget+row["profit_cum"],abs_tol=EPS)
        assert all(self.remaining(k) >= -EPS for k in CHANNELS)
        if self.policy=="E": assert all(self.hours[k] <= self.hour_limit(k)+EPS for k in CHANNELS)
        if self.month==c.months: assert self.pending is None and row["reserves"] < EPS

    def run(self):
        while self.month < self.c.months: self.step()
        last = self.logs["period_results"][-1]
        summary = dict(run_id=self.run_id,seed=self.seed,policy=self.policy,months=self.c.months,
                       new_customers=last["new_customers"],customers=last["customers"],
                       early_sales=sum(r["sales"] for r in self.logs["period_results"] if r["month"]<=12),
                       profit=last["profit_cum"],adjusted_profit=last["adjusted_profit_cum"],
                       marketing_cost=last["marketing_cost_cum"],hours=last["hours_cum"],
                       aware=last["aware"],communities_reached=last["communities_reached"],
                       communities_customers=last["communities_customers"],
                       unserved=sum(r["unserved"] for r in self.logs["period_results"]),
                       unserved_unique=len(self.unserved_people),
                       events=sum(e["status"]=="held" for e in self.logs["events"]),
                       event_links=len(self.logs["event_links"]),
                       pauses=sum(d["action"]=="pause" for d in self.logs["decisions"]),
                       switches=sum(a["action"]!=b["action"] for a,b in zip(self.logs["decisions"],self.logs["decisions"][1:])),
                       cost_per_customer=ratio(last["marketing_cost_cum"],last["new_customers"]),
                       final_free_budget=last["free_budget"],final_reserves=last["reserves"])
        return dict(summary=summary,tables=self.logs)
