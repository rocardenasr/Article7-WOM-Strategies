"""Analyze completed paired baseline runs. Bootstrap replicates, never agents/months."""
import argparse
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .model import POLICIES

PLOT_LABELS=dict(A='Organic',B='Referrals',C='Incentives',D='Events',E='Mixed',F='Sequence',G='Adaptive')


def analyze(source,out):
    source=Path(source); out=Path(out); out.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(source/'run_summary.csv')
    periods=pd.read_csv(source/'period_results.csv')
    decisions=pd.read_csv(source/'decisions.csv')
    seeds=sorted(d.seed.unique()); policies=sorted(d.policy.unique())
    assert policies==list(POLICIES)
    assert len(d)==len(seeds)*7 and not d.duplicated(['seed','policy']).any()
    rng=np.random.Generator(np.random.PCG64(700007))
    indices=rng.integers(0,len(seeds),(5000,len(seeds)))
    metrics=['new_customers','early_sales','profit','adjusted_profit','marketing_cost','hours',
             'aware','communities_reached','communities_customers','events','event_links','unserved']
    rows=[]; pairs=[]; bootstraps={}; arrays={}
    for metric in metrics:
        matrix=d.pivot(index='seed',columns='policy',values=metric).loc[seeds,policies].to_numpy()
        boot=matrix[indices].mean(axis=1)
        arrays[metric]=matrix; bootstraps[metric]=boot
        for j,p in enumerate(policies):
            lo,hi=np.quantile(boot[:,j],[.025,.975])
            rows.append(dict(policy=p,label=POLICIES[p],metric=metric,n=len(seeds),mean=matrix[:,j].mean(),
                             median=np.median(matrix[:,j]),sd=matrix[:,j].std(ddof=1),
                             monte_carlo_se=matrix[:,j].std(ddof=1)/np.sqrt(len(seeds)),ci95_low=lo,ci95_high=hi))
        comparisons=[(p,'A') for p in policies if p!='A']+[('G',p) for p in 'BCDEF']
        for lhs,rhs in comparisons:
            i,j=policies.index(lhs),policies.index(rhs)
            delta=matrix[:,i]-matrix[:,j]
            lo,hi=np.quantile(boot[:,i]-boot[:,j],[.025,.975])
            pairs.append(dict(metric=metric,comparison=lhs+'-'+rhs,n=len(seeds),mean_difference=delta.mean(),
                              ci95_low=lo,ci95_high=hi,monte_carlo_se=delta.std(ddof=1)/np.sqrt(len(seeds))))
    summary=pd.DataFrame(rows); summary.to_csv(out/'policy_summary.csv',index=False)
    pd.DataFrame(pairs).to_csv(out/'paired_contrasts.csv',index=False)
    counts=pd.crosstab(decisions.policy,decisions.action).reindex(policies,fill_value=0)
    counts.to_csv(out/'decision_counts.csv')
    g=decisions[decisions.policy=='G']
    gmonthly=pd.crosstab(g.month,g.action).div(len(seeds))
    gmonthly.to_csv(out/'adaptive_actions_by_month.csv')
    pathways=d[d.policy=='G'][['seed','events','new_customers','adjusted_profit','pauses','switches']]
    pathways.to_csv(out/'adaptive_run_diagnostics.csv',index=False)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    colors=['#3F6670','#467DA6','#A37F3B','#8262A4','#B56A54','#578A70','#C04F5E']
    fig,axes=plt.subplots(1,2,figsize=(11.5,4.8),layout='constrained')
    for ax,metric,title,xlabel in zip(axes,['new_customers','adjusted_profit'],
                                    ['Customer acquisition','Profit including marketing time'],
                                    ['New customers at month 60','Illustrative monetary units']):
        s=summary[summary.metric==metric].set_index('policy').loc[policies]
        means=s['mean'].to_numpy(); err=np.array([means-s.ci95_low.to_numpy(),s.ci95_high.to_numpy()-means])
        ax.barh(np.arange(7),means,color=colors,xerr=err,capsize=3,height=.64)
        ax.set_yticks(np.arange(7),[f'{p} · {PLOT_LABELS[p]}' for p in policies]); ax.invert_yaxis()
        ax.set_title(title,fontweight='bold'); ax.set_xlabel(xlabel); ax.axvline(0,color='#777',lw=.7)
        ax.grid(axis='x',alpha=.2); ax.set_axisbelow(True)
    fig.suptitle(f'Article 7 · Baseline simulation · {len(seeds)} paired repetitions per policy\nMeans and 95% Monte Carlo bootstrap intervals',fontsize=12)
    fig.savefig(out/'baseline_policy_comparison.png',dpi=200)
    fig.savefig(out/'baseline_policy_comparison.svg')
    plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11.5,4.8),layout='constrained')
    for p,color in zip(policies,colors):
        curve=periods[periods.policy==p].groupby('month').new_customers.mean()
        axes[0].plot(curve.index,curve.values,label=f'{p} · {PLOT_LABELS[p]}',color=color)
    axes[0].set(xlabel='Month',ylabel='Mean new customers',title='Acquisition trajectories')
    axes[0].legend(fontsize=8); axes[0].grid(alpha=.2)
    action_colors={'referral':'#467DA6','incentive':'#A37F3B','event':'#8262A4','hold_event':'#B9A5D0','pause':'#B7BEC4'}
    bottom=np.zeros(len(gmonthly))
    for action in ['referral','incentive','event','hold_event','pause']:
        vals=gmonthly.get(action,pd.Series(0,index=gmonthly.index)).to_numpy()
        axes[1].bar(gmonthly.index,vals,bottom=bottom,label=action,color=action_colors[action],width=1)
        bottom+=vals
    axes[1].set(xlabel='Month',ylabel='Share of adaptive runs',title='Actions selected by policy G',ylim=(0,1),xlim=(.5,60.5))
    axes[1].legend(fontsize=8,loc='upper left')
    fig.savefig(out/'trajectories_and_adaptation.png',dpi=200)
    fig.savefig(out/'trajectories_and_adaptation.svg')
    plt.close(fig)
    (out/'analysis_metadata.json').write_text(json.dumps(dict(bootstrap_repetitions=5000,bootstrap_seed=700007,
       unit='paired simulation repetition (all seven policies)',interval='percentile 95%; Monte Carlo uncertainty',
       simultaneous_intervals=False,empirical_uncertainty=False,source=str(source),runs=len(d)),indent=2))
    print(d.groupby('policy')[['new_customers','profit','adjusted_profit','events','unserved']].mean().round(3).to_string())
    print(counts.to_string())


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',default='outputs/main');p.add_argument('--out',default='outputs/analysis')
    a=p.parse_args();analyze(a.source,a.out)
