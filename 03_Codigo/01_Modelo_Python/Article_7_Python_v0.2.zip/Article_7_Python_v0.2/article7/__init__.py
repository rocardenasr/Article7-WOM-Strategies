"""Article 7: transparent agent-based WOM model."""
__version__ = "0.2.0"
