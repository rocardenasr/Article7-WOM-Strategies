"""Command-line experiments, complete trace export and independent reconciliation."""
import argparse
import csv
import gzip
import json
import sys
import platform
import time
from datetime import datetime, timezone
from pathlib import Path
from dataclasses import asdict
from hashlib import sha256
from collections import Counter
import numpy as np
from .model import Config, Model, make_initial, POLICIES, adaptive_action
from . import __version__


def plain(x):
    if isinstance(x,np.generic): return x.item()
    if isinstance(x,np.ndarray): return x.tolist()
    raise TypeError(type(x).__name__)


def json_text(x):
    return json.dumps(x,default=plain,sort_keys=True,ensure_ascii=False,allow_nan=False)


def write_csv(path,rows):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    fields=list(dict.fromkeys(k for row in rows for k in row)) or ['run_id']
    opener=gzip.open if path.suffix=='.gz' else open
    with opener(path,'wt',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader()
        for row in rows:
            writer.writerow({k:('NA' if v is None else json_text(v) if isinstance(v,(list,dict)) else v) for k,v in row.items()})


def audit(result,c):
    """Reconcile exported event-level ledgers with period and run accounting."""
    tables=result['tables']; summary=result['summary']
    expenses={}; sold_people=set(); purchases={}; exposure_ids=set(); events={}; ref_pairs=set()
    paid=0; prior_customers=c.initial_customers; prior_known=c.initial_customers
    for e in tables['events']:
        if e['status']=='held': events[e['event_id']]=set(e['attendees'])
    for link in tables['event_links']:
        assert link['i'] in events[link['event_id']] and link['j'] in events[link['event_id']]
    for e in tables['recommendations']:
        assert e['energy_before']+1e-9>=c.energy_cost
        if e['kind']=='referral':
            pair=(e['sender'],e['receiver']); assert pair not in ref_pairs; ref_pairs.add(pair)
    for row in tables['period_results']:
        month=row['month']
        ex=[e for e in tables['exposures_and_sales'] if e['month']==month]
        ref=[e for e in tables['referral_requests'] if e['month']==month]
        inc=[e for e in tables['incentive_offers'] if e['month']==month]
        ev=[e for e in tables['events'] if e['month']==month]
        assert len(ex)==row['exposures']
        assert sum(e['served'] for e in ex)==row['sales']
        assert sum(e['purchase_decision'] for e in ex)==row['demand']
        assert sum(e['repeated'] for e in ex)==row['repeated_exposures']
        assert prior_customers+row['sales']==row['customers']
        assert prior_known+row['new_reach']==row['aware']
        prior_customers=row['customers']; prior_known=row['aware']
        costs=[sum(e['cost'] for e in ref),sum(e['paid'] for e in inc),sum(e['cost'] for e in ev)]
        for field,total in zip(('referral_cost','incentive_cost','event_cost'),costs):
            assert abs(row[field]-total)<1e-7
        hrs=sum(e['hours'] for e in ref+inc+ev)
        assert abs(hrs-row['hours'])<1e-7
        assert abs(row['profit']-(c.price-c.service_cost)*row['sales']+sum(costs))<1e-7
        assert abs(row['adjusted_profit']-row['profit']+c.time_cost*hrs)<1e-7
        decisive=Counter(e['receiver'] for e in ex if e['decisive'])
        assert all(v==1 for v in decisive.values())
        for e in ex:
            assert e['exposure_id'] not in exposure_ids; exposure_ids.add(e['exposure_id'])
            if e['served']:
                assert e['receiver'] not in sold_people
                sold_people.add(e['receiver']); purchases[e['receiver']]=month
            if e['reward_paid']:
                assert e['served'] and e['offer'] and e['decisive']; paid+=e['reward_paid']
        if summary['policy']=='G' and c.campaigns_enabled:
            d=tables['decisions'][month-1]
            history=tables['period_results'][max(0,month-1-c.window):month-1]
            total_ex=sum(p['exposures'] for p in history)
            total_prom=sum(p['promoters_start'] for p in history)
            den_capacity=sum(p['capacity'] for p in history)
            obs=d['observable']
            assert obs['C']==row['customers']-row['sales']
            assert obs['P']==row['promoters_start']
            assert obs['exposures_window']==total_ex
            assert obs['history_months']==len(history)
            assert obs['R3']==(sum(p['repeated_exposures'] for p in history)/total_ex if total_ex else None)
            assert obs['A3']==(sum(p['active_promoters'] for p in history)/total_prom if total_prom else None)
            assert obs['U3']==(sum(p['sales'] for p in history)/den_capacity if den_capacity else None)
            act,rule,skip=adaptive_action(c,obs,d['feasible'],d['pending'])
            assert (act,rule,skip)==(d['action'],d['rule'],d['skipped'])
    for e in tables['recommendations']:
        assert purchases.get(e['sender'],0)<e['month']
    assert abs(paid-sum(e['paid'] for e in tables['incentive_offers']))<1e-7
    assert len(sold_people)==summary['new_customers']
    assert abs(sum(r['profit'] for r in tables['period_results'])-summary['profit'])<1e-7
    assert abs(sum(r['adjusted_profit'] for r in tables['period_results'])-summary['adjusted_profit'])<1e-7
    assert summary['final_reserves']==0
    return dict(run_id=summary['run_id'],status='passed',periods_checked=len(tables['period_results']),
                exposures_checked=len(exposure_ids),sales_checked=len(sold_people))


def run_batch(config_path,out,first,count,policies='ABCDEFG'):
    c=Config(**json.loads(Path(config_path).read_text())); c.validate()
    out=Path(out)
    if out.exists() and any(out.iterdir()): raise ValueError('Output directory must be empty; do not overwrite experiments')
    out.mkdir(parents=True,exist_ok=True)
    files=[Path(__file__).parent/'model.py',Path(__file__)]
    hashes={p.name:sha256(p.read_bytes()).hexdigest() for p in files}
    metadata=dict(version=__version__,python=sys.version,numpy=np.__version__,platform=platform.platform(),
                  source_hashes=hashes,config_sha256=sha256(json_text(asdict(c)).encode()).hexdigest(),
                  config=asdict(c),seeds=list(range(first,first+count)),policies=list(policies),
                  started_at=datetime.now(timezone.utc).isoformat(),purpose='theoretical_baseline_no_empirical_calibration')
    (out/'experiment_manifest.json').write_text(json_text(metadata),encoding='utf-8')
    summaries=[]; periods=[]; decisions=[]; audits=[]; manifest=[]; diagnostics=[]
    start=time.monotonic()
    for seed in range(first,first+count):
        initial=make_initial(c,seed)
        diagnostics.append(dict(seed=seed,fit_redraws=initial['fit_redraws'],**initial['diagnostics']))
        write_csv(out/'initial_conditions'/f's{seed}_network.csv.gz',[
            dict(seed=seed,i=i,j=j,community_i=int(initial['community'][i]),community_j=int(initial['community'][j]))
            for i,nei in enumerate(initial['adj']) for j in sorted(nei) if i<j])
        write_csv(out/'initial_conditions'/f's{seed}_agents.csv.gz',[
            dict(seed=seed,agent=i,**{k:plain(initial[k][i]) for k in ('community','fit','customer','satisfied','willing')})
            for i in range(c.n)])
        for policy in policies:
            model=Model(c,seed,policy,initial)
            try:
                result=model.run(); check=audit(result,c)
            except Exception as exc:
                (out/f'FAILED_s{seed}_{policy}.json').write_text(json_text(dict(error=repr(exc),seed=seed,policy=policy)))
                raise
            audits.append(check); summaries.append(result['summary'])
            periods.extend(result['tables']['period_results']); decisions.extend(result['tables']['decisions'])
            run_id=result['summary']['run_id']
            for name,rows in result['tables'].items():
                if name not in ('period_results','decisions'):
                    write_csv(out/'traces'/run_id/(name+'.csv.gz'),rows)
            manifest.append(dict(run_id=run_id,seed=seed,policy=policy,status='complete_audited',version=__version__,
                                 config_sha256=metadata['config_sha256'],code_sha256=hashes['model.py'],
                                 initial_condition_id=f's{seed}'))
        if (seed-first+1)%10==0 or seed==first+count-1:
            print(f'{seed-first+1}/{count} paired replications; {len(summaries)} runs; {time.monotonic()-start:.1f}s',flush=True)
    for name,rows in [('run_summary',summaries),('period_results',periods),('decisions',decisions),
                      ('audit_results',audits),('run_manifest',manifest),('initial_network_diagnostics',diagnostics)]:
        write_csv(out/(name+'.csv'),rows)
    metadata.update(completed_at=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-start,
                    completed_runs=len(summaries),audited_runs=len(audits))
    (out/'experiment_manifest.json').write_text(json_text(metadata),encoding='utf-8')
    print(json_text(dict(completed=len(summaries),audit_passed=len(audits),seconds=metadata['elapsed_seconds'])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--config',default='configs/baseline.json')
    parser.add_argument('--out',required=True)
    parser.add_argument('--first-seed',type=int,default=1001)
    parser.add_argument('--replications',type=int,default=10)
    parser.add_argument('--policies',default='ABCDEFG')
    args=parser.parse_args()
    run_batch(args.config,args.out,args.first_seed,args.replications,args.policies)
