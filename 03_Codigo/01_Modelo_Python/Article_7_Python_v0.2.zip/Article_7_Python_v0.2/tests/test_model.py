"""Behavioral verification using hand-built networks and independent accounting."""
import unittest
import copy
import json
from dataclasses import replace, asdict
from collections import Counter
import numpy as np
from article7.model import Config, Model, make_initial, adaptive_action, uniform, network_stats, POLICIES


def small(**kwargs):
    base = Config(n=24,communities=2,months=12,initial_customers=3,initial_promoters=2,
                  p_in=.5,p_out=.05,fit_low=1.,fit_high=1.,need_p=.9,conversion=1.,
                  satisfied_p=1.,willing_p=1.,organic_p=.8,event_invites=20,event_capacity=12,
                  event_min_links=2,threshold_customers=5,threshold_promoters=3,min_exposures=2,
                  threshold_invites=2)
    return replace(base,**kwargs)


def commercial(result):
    return [(r['customers'],r['sales'],r['aware'],r['edges'],r['exposures'],r['unserved'])
            for r in result['tables']['period_results']]


class Verification(unittest.TestCase):
    def test_V01_no_customers(self):
        c = small(initial_customers=0,initial_promoters=0)
        for p in POLICIES:
            r = Model(c,11,p).run()
            self.assertEqual(r['summary']['new_customers'],0)
            self.assertFalse(r['tables']['recommendations'])
            self.assertFalse(r['tables']['events'])

    def test_V02_zero_reward(self):
        c = small(reward=0)
        a = Model(c,12,'A').run(); b = Model(c,12,'C').run()
        self.assertEqual(commercial(a),commercial(b))
        self.assertEqual(b['summary']['marketing_cost'],0)
        self.assertEqual(b['summary']['hours'],0)
        self.assertFalse(b['tables']['incentive_offers'])

    def test_V03_no_attendees_fixed_cost_remains(self):
        c = small(event_attendance=0)
        r = Model(c,13,'D').run()
        held = [e for e in r['tables']['events'] if e['status']=='held']
        self.assertEqual(len(held),2)
        self.assertTrue(all(not e['attendees'] and e['new_links']==0 for e in held))
        self.assertEqual(r['summary']['marketing_cost'],2*c.event_fixed)
        self.assertFalse([e for e in r['tables']['exposures_and_sales'] if e['kind']=='event'])

    def test_V04_disconnected_communities(self):
        c = small(p_out=0,p_in=1,event_p_cross=1,event_p_within=1)
        for p in POLICIES:
            m = Model(c,14,p); r = m.run()
            self.assertFalse(np.any(m.customer[m.community==1]))
            self.assertEqual(r['summary']['communities_reached'],1)

    def test_V05_budget_reservations(self):
        for budget in [0,.5,59,71,72,90]:
            c = small(budget=budget)
            for p in POLICIES:
                m=Model(c,15,p); r=m.run()
                for row in r['tables']['period_results']:
                    self.assertGreaterEqual(row['free_budget'],-1e-8)
                    self.assertLessEqual(row['marketing_cost_cum']+row['reserves'],budget+1e-8)
                if budget==0:
                    self.assertEqual(commercial(r),commercial(Model(c,15,'A').run()))

    def test_V06_time_and_future_reservation(self):
        for hours in [0,.01,4,8]:
            c=small(hours=hours,event_base_hours=9)
            for p in POLICIES:
                r=Model(c,16,p).run()
                self.assertTrue(all(x['hours']<=hours+1e-9 for x in r['tables']['period_results']))
                self.assertFalse(r['tables']['events'])
        c=small(hours=12)
        r=Model(c,16,'E').run()
        self.assertFalse(r['tables']['events'])  # 30% of 12 cannot fund 8 prep hours.

    def test_V07_capacity_and_no_unserved_reward(self):
        for capacity in [0,1]:
            c=small(capacity=capacity)
            for p in POLICIES:
                r=Model(c,17,p).run()
                for row in r['tables']['period_results']:
                    self.assertLessEqual(row['sales'],capacity)
                    self.assertEqual(row['revenue'],row['sales']*c.price)
                self.assertTrue(all(e['served'] for e in r['tables']['exposures_and_sales'] if e['reward_paid']))
                if capacity==0: self.assertEqual(r['summary']['new_customers'],0)

    def test_V08_referral_ancestry_and_no_repeat_pair(self):
        c=small(months=24); m=Model(c,18,'B'); r=m.run()
        refs=[e for e in r['tables']['recommendations'] if e['kind']=='referral']
        self.assertGreater(len(refs),0)
        pairs=[]
        for e in refs:
            i,j,t=e['sender'],e['receiver'],e['month']
            self.assertLess(m.purchase_month[i],t)
            self.assertTrue(m.satisfied[i])
            self.assertIn(j,m.initial['adj'][i])
            self.assertTrue(m.purchase_month[j]==-1 or m.purchase_month[j]>=t)
            self.assertTrue(e['request_id'])
            pairs.append((i,j))
        self.assertEqual(len(pairs),len(set(pairs)))

    def test_V09_event_link_ancestry_and_next_month(self):
        c=small(event_attendance=1,event_p_cross=1,event_p_within=1,event_capacity=20)
        m=Model(c,19,'D'); r=m.run()
        held={e['event_id']:e for e in r['tables']['events'] if e['status']=='held'}
        self.assertTrue(r['tables']['event_links'])
        edges=set((i,j) for i,nei in enumerate(m.initial['adj']) for j in nei if i<j)
        for e in r['tables']['event_links']:
            self.assertLess(e['i'],e['j']); self.assertNotIn((e['i'],e['j']),edges)
            edges.add((e['i'],e['j']))
            event=held[e['event_id']]
            self.assertIn(e['i'],event['attendees']); self.assertIn(e['j'],event['attendees'])
            for rec in r['tables']['recommendations']:
                if {rec['sender'],rec['receiver']}=={e['i'],e['j']}:
                    self.assertGreater(rec['month'],e['month'])

    def test_V10_adaptive_priority_and_reconstruction(self):
        c=small(); obs=dict(C=12,P=10,U3=0,A3=.1,R3=.8,M3=.2,Gobs=2,exposures_window=30,history_months=3)
        f=dict(referral=True,incentive=True,event=True)
        self.assertEqual(adaptive_action(c,obs,f,False)[:2],('event',5))
        self.assertEqual(adaptive_action(c,{**obs,'U3':.90},f,False)[:2],('pause',2))
        self.assertEqual(adaptive_action(c,{**obs,'U3':1},f,True)[:2],('hold_event',1))
        self.assertEqual(adaptive_action(c,{**obs,'R3':.2,'Gobs':3},f,False)[:2],('incentive',6))
        self.assertEqual(adaptive_action(c,{**obs,'C':1},f,False)[:2],('referral',4))
        r=Model(c,20,'G').run()
        for d in r['tables']['decisions']:
            action,rule,skipped=adaptive_action(c,d['observable'],d['feasible'],d['pending'])
            self.assertEqual((action,rule,skipped),(d['action'],d['rule'],d['skipped']))

    def test_V11_ablated_campaigns_and_cost_overlay(self):
        c=small(campaigns_enabled=False)
        a=Model(c,21,'A').run()
        for p in POLICIES:
            b=Model(c,21,p).run()
            self.assertEqual(commercial(a),commercial(b))
            self.assertEqual(a['summary']['profit'],b['summary']['profit'])
        profit=a['summary']['profit']
        self.assertGreaterEqual(profit,profit-100)

    def test_V12_equivalent_policies(self):
        c=small(months=18,sequence_ref_end=20)
        a=Model(c,22,'B').run(); b=Model(c,22,'F').run()
        self.assertEqual(commercial(a),commercial(b))
        self.assertEqual(a['summary']['profit'],b['summary']['profit'])
        self.assertEqual(a['summary']['hours'],b['summary']['hours'])

    def test_V13_independent_accounting(self):
        c=small(months=60)
        for p in POLICIES:
            r=Model(c,23,p).run(); tab=r['tables']; s=r['summary']
            ref=sum(x['cost'] for x in tab['referral_requests'])
            inc=sum(x['paid'] for x in tab['incentive_offers'])
            ev=sum(x['cost'] for x in tab['events'])
            hrs=sum(x['hours'] for x in tab['referral_requests'])+sum(x['hours'] for x in tab['incentive_offers'])+sum(x['hours'] for x in tab['events'])
            sold=sum(x['served'] for x in tab['exposures_and_sales'])
            self.assertAlmostEqual(ref+inc+ev,s['marketing_cost'])
            self.assertAlmostEqual(hrs,s['hours'])
            self.assertAlmostEqual(sold*(c.price-c.service_cost)-ref-inc-ev,s['profit'])
            self.assertAlmostEqual(s['profit']-c.time_cost*hrs,s['adjusted_profit'])
            self.assertAlmostEqual(c.budget-ref-inc-ev,s['final_free_budget'])

    def test_V14_reproducibility_and_order(self):
        c=small()
        forward={p:Model(c,24,p).run() for p in POLICIES}
        reverse={p:Model(c,24,p).run() for p in reversed(POLICIES)}
        self.assertEqual(forward,reverse)
        self.assertNotEqual(uniform(1,14,1,1),uniform(1,14,1,2))

    def test_V15_manual_multiple_exposures_one_sale_one_reward(self):
        c=small(capacity=1,need_p=1,conversion=2)
        m=Model(c,25,'C'); m.month=1; m.exposures=[]
        i=int(m.promoters()[0]); j=int(np.flatnonzero(~m.customer)[0])
        m.expose(i,j,'organic',before=1)
        m.expose(-1,j,'event',event_id='manual')
        demand,sales=m.settle_exposures({})
        self.assertEqual((demand,sales),(1,1))
        self.assertEqual(sum(e['decisive'] for e in m.exposures),1)
        self.assertEqual(sum(e['served'] for e in m.exposures),1)

    def test_V16_energy_and_new_customer_delay(self):
        c=small(energy_recovery=0,energy_cost=.4,months=30,organic_p=1)
        m=Model(c,26,'E'); r=m.run()
        for rec in r['tables']['recommendations']:
            self.assertGreaterEqual(rec['energy_before']+1e-9,c.energy_cost)
            self.assertGreaterEqual(rec['energy_after'],0)
            self.assertLess(m.purchase_month[rec['sender']],rec['month'])
        exhausted=small(energy_initial=0,energy_recovery=0)
        self.assertFalse(Model(exhausted,26,'B').run()['tables']['recommendations'])

    def test_V17_mixed_and_sequence_calendar(self):
        c=small(months=60,budget=10000)
        m=Model(c,27,'E'); r=m.run()
        for k,share in zip(('referral','incentive','event'),(.4,.3,.3)):
            self.assertLessEqual(m.spent[k],c.budget*share+1e-9)
            self.assertTrue(all(row['hours_by_channel'][k]<=c.hours*share+1e-9 for row in r['tables']['period_results']))
        r=Model(c,27,'F').run()
        d=r['tables']['decisions']
        self.assertTrue(all(x['action']=='referral' for x in d[:20]))
        self.assertTrue(all(x['action']=='incentive' for x in d[20:40]))
        self.assertEqual([e['month'] for e in r['tables']['events'] if e['status']=='prepared'],[41,47,53,59])
        self.assertEqual([e['month'] for e in r['tables']['events'] if e['status']=='held'],[42,48,54,60])

    def test_V18_na_windows(self):
        c=small(initial_customers=0,initial_promoters=0)
        m=Model(c,28,'G')
        obs=m.observable()
        self.assertIsNone(obs['U3']); self.assertIsNone(obs['R3']); self.assertIsNone(obs['A3'])
        r=m.run()
        self.assertTrue(all(x['redundancy'] is None for x in r['tables']['period_results']))
        self.assertIsNone(r['summary']['cost_per_customer'])
        self.assertEqual(r['tables']['decisions'][-1]['observable']['history_months'],3)

    def test_V19_no_terminal_commitments(self):
        for horizon in [1,2,7,60]:
            c=small(months=horizon)
            for p in POLICIES:
                r=Model(c,29,p).run()
                self.assertEqual(r['summary']['final_reserves'],0)
                self.assertTrue(all(e['month']<horizon for e in r['tables']['events'] if e['status']=='prepared'))

    def test_V20_individual_monthly_aggregation(self):
        c=small(months=60)
        for p in POLICIES:
            r=Model(c,30,p).run()
            for row in r['tables']['period_results']:
                ex=[e for e in r['tables']['exposures_and_sales'] if e['month']==row['month']]
                self.assertEqual(len(ex),row['exposures'])
                self.assertEqual(sum(e['served'] for e in ex),row['sales'])
                self.assertEqual(sum(e['purchase_decision'] for e in ex),row['demand'])
                self.assertEqual(sum(e['repeated'] for e in ex),row['repeated_exposures'])
            buyers=[e['receiver'] for e in r['tables']['exposures_and_sales'] if e['served']]
            self.assertEqual(len(buyers),len(set(buyers)))
            self.assertEqual(len(buyers),r['summary']['new_customers'])

    def test_extra_manual_chain_capacity_and_profit(self):
        c=small(n=4,communities=1,initial_customers=1,initial_promoters=1,months=3,
                need_p=1,conversion=2,organic_p=1,energy_cost=0,energy_recovery=0,capacity=1)
        init=make_initial(c,40)
        root=int(np.flatnonzero(init['customer'])[0]); others=[i for i in range(4) if i!=root]
        path=[root]+others; adj=[set() for _ in range(4)]
        for i,j in zip(path,path[1:]): adj[i].add(j); adj[j].add(i)
        init['adj']=adj; init['satisfied'][:]=True; init['willing'][:]=True
        m=Model(c,40,'A',init); r=m.run()
        self.assertEqual([x['sales'] for x in r['tables']['period_results']],[1,1,1])
        self.assertEqual(r['summary']['profit'],24)
        self.assertEqual([m.purchase_month[i] for i in path],[0,1,2,3])

    def test_extra_manual_incentive_settlement(self):
        c=small(n=2,communities=1,initial_customers=1,initial_promoters=1,months=1,need_p=1,
                conversion=2,organic_p=1,energy_cost=0,energy_recovery=0,p_in=1)
        r=Model(c,41,'C').run()
        self.assertEqual(r['summary']['new_customers'],1)
        self.assertEqual(r['summary']['marketing_cost'],2)
        self.assertEqual(r['summary']['profit'],6)
        self.assertAlmostEqual(r['summary']['adjusted_profit'],5.8)
        self.assertEqual(r['tables']['incentive_offers'][0]['paid'],2)
        self.assertFalse(r['tables']['incentive_offers'][0]['additional'])

    def test_extra_initial_network_pairing_and_diagnostics(self):
        c=small(); init=make_initial(c,42)
        a=Model(c,42,'A',init); b=Model(c,42,'D',init)
        self.assertEqual(a.adj,b.adj)
        self.assertTrue(np.array_equal(a.fit,b.fit))
        b.adj[0].clear()
        self.assertEqual(a.adj,init['adj'])
        adj=[{1,2},{0,2},{0,1},set()]
        d=network_stats(adj,np.array([0,0,0,1]))
        self.assertEqual(d['edges'],3); self.assertEqual(d['components'],2)
        self.assertAlmostEqual(d['clustering'],.75)

    def test_extra_invalid_configuration(self):
        for kwargs in [dict(n=23),dict(p_in=2),dict(budget=-1),dict(initial_promoters=25),
                       dict(capacity=1.5),dict(fit_high=.5,initial_fit_min=.6)]:
            with self.assertRaises(ValueError): small(**kwargs).validate()


if __name__=='__main__':
    unittest.main(verbosity=2)
