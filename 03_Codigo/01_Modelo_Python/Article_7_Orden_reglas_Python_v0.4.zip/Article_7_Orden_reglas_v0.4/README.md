# Article 7 — Comparación de órdenes de reglas v0.4

Este paquete conserva el motor v0.2.0 y añade una intervención que cambia únicamente el orden de las reglas 4–7 de G. Se enumeran las 24 permutaciones con parámetros basales y semillas 2001–2100. Las guardas 1–3 y la pausa final 8 no se reordenan.

## Reproducción completa

Requiere Python 3.10 o superior. Entorno ejecutado: Python 3.12.14; las versiones exactas de dependencias figuran en `requirements-tested.txt`.

```bash
python -m pip install -r requirements-tested.txt
python -m unittest discover -s tests -v
python -m article7.order_experiment --design configs/rule_order_design_v0.4.json --out outputs/rule_orders_v0.4 --baseline reference_baseline --workers 4
python -m article7.analyze_orders --source outputs/rule_orders_v0.4 --baseline reference_baseline --out outputs/order_analysis_v0.4
```

Se ejecutan 2.300 casos alternativos y 100 reproducciones de la referencia. Los 600 casos de políticas fijas se reutilizan. `reference_baseline/` incluye resúmenes, series, decisiones y auditorías del experimento basal. El ejecutor verifica sus hashes de motor y configuración y compara los resultados y 6.000 decisiones de G con la nueva reproducción.

El directorio de simulación debe estar vacío. No se sobrescriben ni reanudan automáticamente experimentos existentes. Puede reducir `--workers`; el número de procesos no forma parte de los sorteos. Las semillas son las unidades independientes.

## Reproducir solo el análisis

Extraiga las dos partes `Article_7_Orden_reglas_datos_v0.4_parte*.zip` en el mismo directorio `datos/`; luego ejecute:

```bash
python -m article7.analyze_orders --source datos/rule_orders_v0.4 --baseline reference_baseline --out analysis_reproduced
```

Las rutas de las partes son disjuntas. La primera incluye condiciones iniciales comunes, diseño y manifiestos. La clave global es `(variant, run_id)`; `run_id` conserva el nombre de G y se repite entre variantes. Cada carpeta y manifiesto identifica el orden. `rule` y el campo heredado `skipped.priority` son identificadores estables de reglas, no sus nuevas posiciones.

## Verificación y análisis

Hay 39 pruebas: 29 anteriores y diez específicas. `rule_orders.py` hereda todos los mecanismos originales y sustituye la elección de acción solo para G. El auditor conserva las comprobaciones contables del original y reconstruye la selección mediante un oráculo independiente, sin mutar el módulo original.

Cada contraste usa 100 semillas emparejadas. El análisis realiza 5.000 remuestreos y reporta intervalos marginales; las 46 comparaciones primarias frente al orden original incorporan bandas simultáneas aproximadas. Consultar el protocolo para la definición exacta. No se presentan p-valores ni se interpreta el mejor promedio como un óptimo validado.

El informe y la verificación están en `docs/`. `SOURCE_SHA256.json` registra los archivos del paquete. El notebook está comprobado sintácticamente; la interfaz de Colab no se ejecutó desde Colab. Los comandos principales sí se ejecutaron localmente.
