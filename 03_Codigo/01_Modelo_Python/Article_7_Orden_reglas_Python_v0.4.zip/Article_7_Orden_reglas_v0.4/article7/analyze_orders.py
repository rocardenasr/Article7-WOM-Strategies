"""Paired analysis of all 24 rule orders and a prespecified simultaneous band."""
import argparse
import json
from collections import Counter, defaultdict
from hashlib import sha256
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .model import Config
from .rule_orders import rule_conditions


def analyze(source, baseline, out):
    source,baseline,out=map(Path,(source,baseline,out));out.mkdir(parents=True,exist_ok=True)
    design=json.loads((source/'frozen_design.json').read_text())
    c=Config(**design['baseline']);seeds=design['seeds'];n=len(seeds)
    variants=[x['variant'] for x in design['orders']];reference=design['reference']
    primary=design['primary_metrics'];metrics=primary+design['secondary_metrics']
    runs=pd.read_csv(source/'all_run_summary.csv')
    fixed=pd.read_csv(baseline/'run_summary.csv').query("policy != 'G'").copy();fixed.insert(0,'variant',fixed.policy)
    cases=pd.concat([runs,fixed],ignore_index=True)
    assert len(cases)==3000 and not cases.duplicated(['variant','seed']).any()
    cases.to_csv(out/'all_comparison_cases.csv',index=False)
    rng=np.random.default_rng(design['bootstrap_seed'])
    indices=rng.integers(0,n,(design['bootstrap_replications'],n))
    weights=np.stack([np.bincount(row,minlength=n) for row in indices])/n
    columns=variants+list('ABCDEF');stats=[];contrasts=[];context=[];primary_boot=[];primary_se=[]
    bymetric={}
    for metric in metrics:
        values=cases.pivot(index='seed',columns='variant',values=metric).loc[seeds,columns].to_numpy()
        bootstrap=weights@values;bymetric[metric]=(values,bootstrap)
        for j,v in enumerate(columns):
            lo,hi=np.quantile(bootstrap[:,j],[.025,.975])
            stats.append(dict(variant=v,metric=metric,n=n,mean=values[:,j].mean(),sd=values[:,j].std(ddof=1),
                              mcse=values[:,j].std(ddof=1)/np.sqrt(n),ci95_low=lo,ci95_high=hi))
        for j,v in enumerate(variants[1:],1):
            diff=values[:,j]-values[:,0];boots=bootstrap[:,j]-bootstrap[:,0]
            se=diff.std(ddof=1)/np.sqrt(n);lo,hi=np.quantile(boots,[.025,.975])
            contrasts.append(dict(variant=v,reference=reference,metric=metric,n=n,mean_difference=diff.mean(),
                                  mcse=se,ci95_low=lo,ci95_high=hi))
            if metric in primary:
                primary_boot.append(boots-diff.mean());primary_se.append(se)
        if metric in primary:
            for j,v in enumerate(variants):
                for p in 'ABCDEF':
                    k=columns.index(p);diff=values[:,j]-values[:,k];boots=bootstrap[:,j]-bootstrap[:,k]
                    lo,hi=np.quantile(boots,[.025,.975])
                    context.append(dict(variant=v,reference=p,metric=metric,n=n,mean_difference=diff.mean(),
                                        mcse=diff.std(ddof=1)/np.sqrt(n),ci95_low=lo,ci95_high=hi))
    se=np.array(primary_se);centered=np.column_stack(primary_boot);valid=se>1e-12
    max_t=np.max(np.abs(centered[:,valid]/se[valid]),axis=1) if valid.any() else np.zeros(len(weights))
    critical=float(np.quantile(max_t,.95))
    for row in contrasts:
        if row['metric'] in primary:
            row['simultaneous95_low']=row['mean_difference']-critical*row['mcse']
            row['simultaneous95_high']=row['mean_difference']+critical*row['mcse']
            row['family_size']=46
    pd.DataFrame(stats).to_csv(out/'alternative_summary.csv',index=False)
    pd.DataFrame(contrasts).to_csv(out/'paired_order_contrasts.csv',index=False)
    pd.DataFrame(context).to_csv(out/'exploratory_fixed_policy_contrasts.csv',index=False)
    actions=[];diagnostics=[];signature_groups=defaultdict(list)
    for variant in variants:
        frame=pd.read_csv(source/variant/'decisions.csv')
        signature=sha256((source/variant/'period_results.csv').read_bytes()).hexdigest()
        signature_groups[signature].append(variant)
        for seed,g in frame.groupby('seed',sort=True):
            row=dict(variant=variant,seed=int(seed),months=len(g),
                     incentive_numeric_months=0,incentive_guarded_months=0,incentive_infeasible_months=0,
                     incentive_feasible_no_guard=0,incentive_blocked_by_4=0,incentive_blocked_by_5=0,
                     incentive_blocked_by_7=0)
            counts=g.action.value_counts()
            for action in ['referral','incentive','event','hold_event','pause']:
                row[action+'_months']=int(counts.get(action,0))
                actions.append(dict(variant=variant,seed=int(seed),action=action,months=row[action+'_months']))
            for d in g.itertuples():
                masks=rule_conditions(c,json.loads(d.observable));f=json.loads(d.feasible)
                if not masks[6]:continue
                row['incentive_numeric_months']+=1
                if d.rule in [1,2,3]:row['incentive_guarded_months']+=1
                elif not f['incentive']:row['incentive_infeasible_months']+=1
                else:
                    row['incentive_feasible_no_guard']+=1
                    if d.rule in [4,5,7]:row[f'incentive_blocked_by_{d.rule}']+=1
                    else:assert d.rule==6
            assert row['incentive_feasible_no_guard']==row['incentive_months']+sum(row[f'incentive_blocked_by_{i}'] for i in [4,5,7])
            assert row['incentive_numeric_months']==row['incentive_guarded_months']+row['incentive_infeasible_months']+row['incentive_feasible_no_guard']
            diagnostics.append(row)
    action=pd.DataFrame(actions);diag=pd.DataFrame(diagnostics)
    action.to_csv(out/'actions_by_replication.csv',index=False)
    diag.to_csv(out/'mechanisms_by_replication.csv',index=False)
    totals=diag.drop(columns='seed').groupby('variant',sort=False).sum()
    totals['runs_with_incentives']=diag.groupby('variant',sort=False).incentive_months.apply(lambda x:int((x>0).sum()))
    totals['runs_with_events']=diag.groupby('variant',sort=False).event_months.apply(lambda x:int((x>0).sum()))
    totals.to_csv(out/'mechanism_totals.csv')
    group_rows=[]
    for i,(digest,group) in enumerate(signature_groups.items(),1):
        for v in group:group_rows.append(dict(variant=v,observed_series_group=i,period_results_sha256=digest))
    pd.DataFrame(group_rows).to_csv(out/'observed_monthly_series_groups.csv',index=False)
    manifest=dict(executions=2400,new_alternative_runs=2300,reference_reproductions=100,reused_fixed_policy_runs=600,
                  independent_seeds_per_contrast=100,bootstrap_replications=len(weights),bootstrap_seed=design['bootstrap_seed'],
                  primary_contrasts=46,simultaneous_critical_value=critical,nonconstant_primary_contrasts=int(valid.sum()),
                  interval_method='marginal percentile plus approximate simultaneous bootstrap max-|t| using observed paired MCSE',
                  observed_monthly_series_groups=len(signature_groups),analysis_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
                  scope='all orders at baseline parameters; no empirical calibration, no parameter-robust optimality claim')
    (out/'analysis_manifest.json').write_text(json.dumps(manifest,indent=2))
    figures=pd.DataFrame(contrasts);figdir=out/'figures';figdir.mkdir(exist_ok=True)
    fig,axes=plt.subplots(1,2,figsize=(12,10),layout='constrained')
    for ax,metric,title in zip(axes,primary,['Clientes nuevos','Utilidad ajustada (UM; tiempo = 2 UM/h)']):
        d=figures[figures.metric==metric].set_index('variant').loc[variants[1:]]
        y=np.arange(len(d));x=d.mean_difference.to_numpy()
        error=np.stack([x-d.simultaneous95_low.to_numpy(),d.simultaneous95_high.to_numpy()-x])
        ax.errorbar(x,y,xerr=error,fmt='o',markersize=4,capsize=2,color='#186c8c',elinewidth=1.3)
        ax.axvline(0,color='#777777',ls='--',lw=1)
        ax.set_yticks(y,['–'.join(v[2:]) for v in d.index]);ax.invert_yaxis()
        ax.set_title(title,fontweight='bold');ax.set_xlabel('Diferencia media frente a 4–5–6–7')
        ax.grid(axis='x',alpha=.2)
    axes[0].set_ylabel('Orden de reglas')
    fig.suptitle('Article 7 · Efecto del orden de las reglas adaptativas\n100 semillas emparejadas; bandas simultáneas aproximadas del 95% para 46 contrastes',fontsize=13)
    fig.savefig(figdir/'order_effects.png',dpi=180);fig.savefig(figdir/'order_effects.svg');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(13,10),layout='constrained')
    left=np.zeros(len(variants));y=np.arange(len(variants))
    for action,label,color in [('referral','Referidos','#32678c'),('incentive','Incentivos','#f3b04f'),
                                ('event','Preparar evento','#4e9971'),('hold_event','Celebrar evento','#9cc1a7'),('pause','Pausa','#d6d6d6')]:
        values=totals.loc[variants,action+'_months'].to_numpy()/6000*100
        axes[0].barh(y,values,left=left,color=color,label=label,height=.75);left+=values
    axes[0].set_yticks(y,['–'.join(v[2:]) for v in variants]);axes[0].invert_yaxis()
    axes[0].set_xlabel('Porcentaje de meses');axes[0].set_title('Acciones seleccionadas');axes[0].legend(loc='upper center',bbox_to_anchor=(.5,-.08),ncol=2,fontsize=9)
    summary=pd.DataFrame(stats)
    for v in columns:
        vx=float(summary[(summary.variant==v)&(summary.metric=='new_customers')]['mean'].iloc[0])
        vy=float(summary[(summary.variant==v)&(summary.metric=='adjusted_profit')]['mean'].iloc[0])
        axes[1].scatter(vx,vy,c='#bc4b42' if v==reference else '#186c8c' if v.startswith('G_') else '#666666',s=55 if v==reference else 30)
        if v in ['A','B','C','D','E','F',reference,'G_6457','G_6547']:
            offset={'F':(-18,8),reference:(34,0),'G_6457':(34,20),'G_6547':(34,-20)}.get(v,(4,5))
            axes[1].annotate(v.replace('G_',''),(vx,vy),xytext=offset,textcoords='offset points',fontsize=9,
                             arrowprops=dict(arrowstyle='-',color='#777777',lw=.7) if v.startswith('G_') else None)
    axes[1].set_xlabel('Clientes nuevos medios');axes[1].set_ylabel('Utilidad ajustada media (UM)')
    axes[1].set_title('Captación y utilidad: medias descriptivas')
    axes[1].grid(alpha=.2)
    for color,label in [('#bc4b42','G: orden original'),('#186c8c','G: órdenes alternativos'),('#666666','A–F: políticas fijas')]:
        axes[1].scatter([],[],c=color,s=30,label=label)
    axes[1].legend(loc='upper right',fontsize=9)
    fig.suptitle('Article 7 · Mecanismos y resultados al mes 60\n4: adquisición por referidos · 5: eventos · 6: incentivos · 7: continuación de referidos',fontsize=13)
    fig.savefig(figdir/'order_actions_and_outcomes.png',dpi=180);fig.savefig(figdir/'order_actions_and_outcomes.svg');plt.close(fig)
    print(json.dumps(manifest,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',default='outputs/rule_orders_v0.4')
    p.add_argument('--baseline',default='reference_baseline');p.add_argument('--out',default='outputs/order_analysis_v0.4')
    a=p.parse_args();analyze(a.source,a.baseline,a.out)
