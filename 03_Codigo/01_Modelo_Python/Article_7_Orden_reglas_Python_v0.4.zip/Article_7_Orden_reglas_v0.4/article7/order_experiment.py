"""Reproducible complete enumeration of adaptive action-rule orderings."""
import argparse
import json
import platform
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import numpy as np
import pandas as pd
from .model import Config, make_initial
from .experiment import write_csv, json_text, plain
from .rule_orders import OrderedModel, ORDERS, audit_ordered


def design_document(baseline):
    c = Config(**baseline); c.validate()
    return dict(version='0.4',reference_engine='0.2.0',created_at=datetime.now(timezone.utc).isoformat(),
                intervention='only the order of action rules 4,5,6,7; guards 1,2,3 and default 8 unchanged',
                baseline=asdict(c),seeds=list(range(2001,2101)),
                orders=[dict(variant='G_'+''.join(map(str,o)),order=list(o)) for o in ORDERS],
                reference='G_4567',executions=2400,new_alternative_executions=2300,
                reference_reproduction_executions=100,reused_fixed_policy_runs=600,
                bootstrap_replications=5000,bootstrap_seed=740004,
                primary_metrics=['new_customers','adjusted_profit'],
                primary_family='23 order-vs-reference contrasts x 2 outcomes = 46',
                simultaneous_intervals='bootstrap max absolute standardized centered mean deviation; observed paired MCSE',
                secondary_metrics=['profit','marketing_cost','hours','events','event_links','unserved','aware'],
                scope='baseline parameters only; complete order enumeration, not global parameter sensitivity')


def run_order(job):
    design_path, output, order = job
    design = json.loads(Path(design_path).read_text()); c = Config(**design['baseline'])
    variant = 'G_'+''.join(map(str,order)); out = Path(output)/variant
    out.mkdir(parents=True,exist_ok=False)
    source_files = ['model.py','experiment.py','rule_orders.py','order_experiment.py']
    meta = dict(variant=variant,rule_order=order,config=asdict(c),seeds=design['seeds'],
                python=sys.version,numpy=np.__version__,platform=platform.platform(),
                source_hashes={name:sha256((Path(__file__).parent/name).read_bytes()).hexdigest() for name in source_files},
                started_at=datetime.now(timezone.utc).isoformat())
    (out/'experiment_manifest.json').write_text(json_text(meta))
    summaries=[]; periods=[]; decisions=[]; audits=[]; diagnostics=[]
    for seed in design['seeds']:
        initial = make_initial(c,seed)
        if variant == design['reference']:
            write_csv(Path(output)/'initial_conditions'/f's{seed}_network.csv.gz',[
                dict(seed=seed,i=i,j=j,community_i=int(initial['community'][i]),community_j=int(initial['community'][j]))
                for i,nei in enumerate(initial['adj']) for j in sorted(nei) if i<j])
            write_csv(Path(output)/'initial_conditions'/f's{seed}_agents.csv.gz',[
                dict(seed=seed,agent=i,**{k:plain(initial[k][i]) for k in ('community','fit','customer','satisfied','willing')})
                for i in range(c.n)])
            diagnostics.append(dict(seed=seed,fit_redraws=initial['fit_redraws'],**initial['diagnostics']))
        try:
            result = OrderedModel(c,seed,'G',initial,order).run()
            check = audit_ordered(result,c,order)
        except Exception as exc:
            (out/f'FAILED_s{seed}.json').write_text(json_text(dict(seed=seed,variant=variant,error=repr(exc))))
            raise
        summaries.append(dict(variant=variant,**result['summary']))
        audits.append(dict(variant=variant,**check))
        periods.extend(result['tables']['period_results']);decisions.extend(result['tables']['decisions'])
        for name,rows in result['tables'].items():
            if name not in ('period_results','decisions'):
                write_csv(out/'traces'/result['summary']['run_id']/(name+'.csv.gz'),rows)
    for name,rows in [('run_summary',summaries),('period_results',periods),('decisions',decisions),('audit_results',audits)]:
        write_csv(out/(name+'.csv'),rows)
    if diagnostics:write_csv(Path(output)/'initial_network_diagnostics.csv',diagnostics)
    meta.update(completed_at=datetime.now(timezone.utc).isoformat(),completed_runs=len(summaries),audit_passed=len(audits))
    (out/'experiment_manifest.json').write_text(json_text(meta))
    return variant


def run_experiment(design_path,out,baseline,workers=4):
    design_path=Path(design_path);out=Path(out);baseline=Path(baseline)
    d=json.loads(design_path.read_text()); reference=json.loads((baseline/'experiment_manifest.json').read_text())
    assert reference['config']==d['baseline'] and reference['seeds']==d['seeds']
    for name,digest in reference['source_hashes'].items():
        assert sha256((Path(__file__).parent/name).read_bytes()).hexdigest()==digest
    if out.exists() and any(out.iterdir()):raise ValueError('Output must be empty')
    out.mkdir(parents=True,exist_ok=True)
    (out/'frozen_design.json').write_bytes(design_path.read_bytes())
    manifest=dict(design_sha256=sha256(design_path.read_bytes()).hexdigest(),
                  baseline_manifest_sha256=sha256((baseline/'experiment_manifest.json').read_bytes()).hexdigest(),
                  started_at=datetime.now(timezone.utc).isoformat(),workers=workers)
    (out/'execution_manifest.json').write_text(json_text(manifest))
    start=time.monotonic()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures=[pool.submit(run_order,(str(design_path),str(out),x['order'])) for x in d['orders']]
        for k,future in enumerate(as_completed(futures),1):
            print(f'{k}/24: {future.result()}; {time.monotonic()-start:.1f}s',flush=True)
    summaries=pd.concat([pd.read_csv(out/x['variant']/'run_summary.csv') for x in d['orders']],ignore_index=True)
    audits=pd.concat([pd.read_csv(out/x['variant']/'audit_results.csv') for x in d['orders']],ignore_index=True)
    assert len(summaries)==2400 and len(audits)==2400 and (audits.status=='passed').all()
    assert not summaries.duplicated(['variant','seed']).any()
    old=pd.read_csv(baseline/'run_summary.csv').query("policy == 'G'").set_index('seed')
    new=summaries.query("variant == 'G_4567'").set_index('seed').loc[old.index]
    for col in old.columns:
        if pd.api.types.is_numeric_dtype(old[col]):
            assert np.allclose(old[col],new[col],rtol=0,atol=1e-9,equal_nan=True),col
        else:assert old[col].equals(new[col]),col
    prior=pd.read_csv(baseline/'decisions.csv').query("policy == 'G'").reset_index(drop=True)
    current=pd.read_csv(out/'G_4567/decisions.csv').reset_index(drop=True)
    pd.testing.assert_frame_equal(prior,current)
    summaries.to_csv(out/'all_run_summary.csv',index=False);audits.to_csv(out/'all_audit_results.csv',index=False)
    manifest.update(completed_at=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-start,
                    executions=2400,new_alternative_runs=2300,reference_reproductions=100,
                    audited_periods=int(audits.periods_checked.sum()),reference_summary_fields_matched=len(old.columns),
                    reference_decisions_matched=len(prior))
    (out/'execution_manifest.json').write_text(json_text(manifest));print(json_text(manifest),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--design',default='configs/rule_order_design_v0.4.json')
    p.add_argument('--out',default='outputs/rule_orders_v0.4');p.add_argument('--baseline',default='reference_baseline')
    p.add_argument('--workers',type=int,default=4);a=p.parse_args()
    run_experiment(a.design,a.out,a.baseline,a.workers)
