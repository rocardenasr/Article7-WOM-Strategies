"""Order-only interventions on adaptive rules; the reference engine is unchanged."""
from itertools import permutations
from types import FunctionType
from .model import Model, Config
from .experiment import audit as reference_audit

ORDERS = tuple(permutations((4, 5, 6, 7)))
REFERENCE = (4, 5, 6, 7)
ACTIONS = {4: 'referral', 5: 'event', 6: 'incentive', 7: 'referral'}


def validate_order(order):
    order = tuple(order)
    if len(order) != 4 or set(order) != {4, 5, 6, 7}:
        raise ValueError('Order must contain each rule 4, 5, 6, 7 exactly once')
    return order


def rule_conditions(c, obs):
    return {
        4: obs['C'] < c.threshold_customers or obs['P'] < c.threshold_promoters,
        5: obs['exposures_window'] >= c.min_exposures and
           ((obs['R3'] is not None and obs['R3'] >= c.threshold_redundancy) or
            obs['Gobs'] <= c.threshold_communities),
        6: obs['history_months'] >= c.window and obs['A3'] is not None and
           obs['A3'] < c.threshold_activity and obs['exposures_window'] >= c.min_exposures and
           obs['R3'] is not None and obs['R3'] < c.threshold_redundancy,
        7: obs['history_months'] < c.window or
           (obs['M3'] is not None and obs['M3'] >= c.threshold_marginal and
            obs['exposures_window'] >= c.min_exposures),
    }


def ordered_action(c, obs, feasible, pending, order=REFERENCE):
    order = validate_order(order)
    if pending:
        return 'hold_event', 1, []
    if c.capacity == 0 or (obs['U3'] is not None and obs['U3'] >= c.threshold_utilization):
        return 'pause', 2, []
    if obs['C'] >= c.n or not any(feasible.values()):
        return 'pause', 3, []
    conditions = rule_conditions(c, obs)
    skipped = []
    for rule in order:
        if conditions[rule]:
            action = ACTIONS[rule]
            if feasible[action]:
                return action, rule, skipped
            # 'priority' retains the historical rule ID, not its reordered position.
            skipped.append(dict(priority=rule, action=action, reason='infeasible'))
    return 'pause', 8, skipped


class OrderedModel(Model):
    def __init__(self, config=Config(), seed=1001, policy='G', initial=None, order=REFERENCE):
        self.rule_order = validate_order(order)
        super().__init__(config, seed, policy, initial)

    def choose(self, feasible):
        if self.policy != 'G' or not self.c.campaigns_enabled:
            return super().choose(feasible)
        obs = self.observable()
        action, rule, skipped = ordered_action(self.c, obs, feasible, self.pending is not None, self.rule_order)
        self.emit_log('decisions', dict(action=action, rule=rule, observable=obs, feasible=feasible,
                      skipped=skipped, pending=self.pending is not None,
                      free_budget=self.c.budget-sum(self.spent.values())-sum(self.reserved.values())))
        return action, {action}


def audit_decision(c, o, f, pending, order):
    """Independent declarative oracle; does not call the production selector/masks."""
    if pending:
        return 'hold_event', 1, []
    if c.capacity == 0 or (o['U3'] is not None and o['U3'] >= c.threshold_utilization):
        return 'pause', 2, []
    if o['C'] >= c.n or not (f['referral'] or f['incentive'] or f['event']):
        return 'pause', 3, []
    sufficient = o['exposures_window'] >= c.min_exposures
    active = set()
    if min(o['C']-c.threshold_customers, o['P']-c.threshold_promoters) < 0:
        active.add(4)
    if sufficient:
        if o['Gobs'] <= c.threshold_communities:
            active.add(5)
        elif o['R3'] is not None and o['R3'] >= c.threshold_redundancy:
            active.add(5)
        if o['history_months'] >= c.window and o['A3'] is not None and o['R3'] is not None:
            if o['A3'] < c.threshold_activity and o['R3'] < c.threshold_redundancy:
                active.add(6)
    if o['history_months'] < c.window:
        active.add(7)
    elif sufficient and o['M3'] is not None and o['M3'] >= c.threshold_marginal:
        active.add(7)
    skips = []
    for identifier in order:
        if identifier not in active:
            continue
        action = {4: 'referral', 5: 'event', 6: 'incentive', 7: 'referral'}[identifier]
        if f[action]:
            return action, identifier, skips
        skips.append(dict(priority=identifier, action=action, reason='infeasible'))
    return 'pause', 8, skips


def audit_ordered(result, c, order):
    # Reuse every accounting/trace assertion in the frozen reference auditor.
    # Give the copied function an isolated namespace and an independent oracle;
    # neither the engine nor the reference auditor's globals are modified.
    namespace = dict(reference_audit.__globals__)
    namespace['adaptive_action'] = lambda c, o, f, p: audit_decision(c, o, f, p, order)
    checker = FunctionType(reference_audit.__code__, namespace, 'order_aware_audit')
    return checker(result, c)
