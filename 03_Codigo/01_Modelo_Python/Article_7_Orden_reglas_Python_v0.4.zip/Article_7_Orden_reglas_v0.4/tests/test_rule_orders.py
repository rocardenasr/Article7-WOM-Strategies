import copy
import unittest
from dataclasses import replace
from itertools import product
import numpy as np
from article7.model import Config, Model, adaptive_action
from article7.rule_orders import (ORDERS, REFERENCE, OrderedModel, ordered_action,
                                 validate_order, audit_ordered, rule_conditions)
from article7 import experiment


class RuleOrderVerification(unittest.TestCase):
    def setUp(self):
        self.c=Config()
        self.obs=dict(C=15,P=6,U3=0,A3=.1,R3=.1,M3=.9,Gobs=1,exposures_window=30,history_months=3)
        self.feasible=dict(referral=True,event=True,incentive=True)

    def test_all_orders_and_invalid_orders(self):
        self.assertEqual(len(set(ORDERS)),24)
        for bad in [(4,5,6),(4,5,6,6),(1,4,5,6),(4,5,6,7,8)]:
            with self.assertRaises(ValueError):validate_order(bad)

    def test_reference_selector_at_boundaries(self):
        rng=np.random.default_rng(44004)
        for _ in range(2000):
            red=rng.choice([None,0.,.59,.6,1.])
            obs=dict(C=int(rng.choice([15,29,30,600])),P=int(rng.choice([0,9,10,20])),
                     U3=rng.choice([None,0.,.89,.9,1.]),A3=rng.choice([None,0.,.19,.2,1.]),
                     R3=red,M3=None if red is None else 1-red,Gobs=int(rng.choice([1,2,3,6])),
                     exposures_window=int(rng.choice([0,19,20,30])),history_months=int(rng.choice([0,2,3])))
            feasible={k:bool(rng.integers(2)) for k in self.feasible}
            pending=bool(rng.integers(2))
            self.assertEqual(ordered_action(self.c,obs,feasible,pending),adaptive_action(self.c,obs,feasible,pending))

    def test_guards_never_reordered(self):
        for order in ORDERS:
            self.assertEqual(ordered_action(self.c,self.obs,self.feasible,True,order),('hold_event',1,[]))
            self.assertEqual(ordered_action(self.c,{**self.obs,'U3':.9},self.feasible,False,order),('pause',2,[]))
            self.assertEqual(ordered_action(replace(self.c,capacity=0),self.obs,self.feasible,False,order),('pause',2,[]))
            self.assertEqual(ordered_action(self.c,{**self.obs,'C':600},self.feasible,False,order),('pause',3,[]))
            self.assertEqual(ordered_action(self.c,self.obs,dict.fromkeys(self.feasible,False),False,order),('pause',3,[]))

    def test_hand_calculated_overlapping_rules(self):
        actions={4:'referral',5:'event',6:'incentive',7:'referral'}
        for order in ORDERS:
            self.assertEqual(ordered_action(self.c,self.obs,self.feasible,False,order),(actions[order[0]],order[0],[]))

    def test_infeasible_rule_skips_to_next_eligible(self):
        action,rule,skips=ordered_action(self.c,self.obs,dict(referral=False,event=False,incentive=True),False,(4,7,6,5))
        self.assertEqual((action,rule),('incentive',6))
        self.assertEqual([x['priority'] for x in skips],[4,7])

    def test_default_pause_preserved(self):
        obs={**self.obs,'C':40,'P':20,'history_months':3,'exposures_window':0}
        for order in ORDERS:self.assertEqual(ordered_action(self.c,obs,self.feasible,False,order),('pause',8,[]))

    def test_reference_complete_trajectories(self):
        for seed in [2001,2002,2003]:
            self.assertEqual(Model(self.c,seed,'G').run(),OrderedModel(self.c,seed,'G',order=REFERENCE).run())

    def test_fixed_policies_and_campaign_ablation_unchanged(self):
        c=replace(self.c,months=12)
        for policy in 'ABCDEF':
            self.assertEqual(Model(c,2001,policy).run(),OrderedModel(c,2001,policy,order=(6,5,4,7)).run())
        c=replace(c,campaigns_enabled=False)
        self.assertEqual(Model(c,2001,'G').run(),OrderedModel(c,2001,'G',order=(7,6,5,4)).run())

    def test_independent_audit_detects_changed_decision_and_no_global_mutation(self):
        selector=experiment.adaptive_action
        order=(6,4,5,7)
        result=OrderedModel(self.c,2001,order=order).run()
        self.assertEqual(audit_ordered(result,self.c,order)['status'],'passed')
        broken=copy.deepcopy(result);broken['tables']['decisions'][0]['rule']=8
        with self.assertRaises(AssertionError):audit_ordered(broken,self.c,order)
        self.assertIs(experiment.adaptive_action,selector)

    def test_referral_continuation_preempts_incentives_when_earlier(self):
        # With baseline thresholds and coherent R3/M3, eligibility for rule 6
        # implies rule 7; a feasible earlier 7 must therefore preempt 6.
        for red in np.linspace(0,.599,100):
            obs={**self.obs,'R3':float(red),'M3':1-float(red)}
            self.assertTrue(rule_conditions(self.c,obs)[6])
            self.assertTrue(rule_conditions(self.c,obs)[7])
            for order in ORDERS:
                if order.index(7)<order.index(6):
                    self.assertNotEqual(ordered_action(self.c,obs,self.feasible,False,order)[1],6)


if __name__=='__main__':unittest.main(verbosity=2)
